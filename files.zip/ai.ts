// src/lib/ai.ts
import { OpenAI } from "openai";
import { prisma } from "./prisma";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * System prompt for Casa Milan AI Assistant
 */
const SYSTEM_PROMPT = `You are Casa Milan Atelier's luxury shopping assistant. Your role is to provide helpful, personalized guidance to customers shopping for premium loungewear.

Brand Information:
- Brand: Casa Milan Atelier
- Tagline: Luxury with Purpose
- Mission: Create affordable luxury loungewear while donating 50 pesewas per item to orphanage homes
- Values: Elegance, Purpose, Authenticity, Comfort

Your responsibilities:
1. Help customers find products that match their needs and style
2. Provide sizing guidance and material information
3. Explain care instructions for products
4. Describe our social impact and donation program
5. Answer questions about policies, shipping, and delivery
6. Provide outfit recommendations based on customer preferences
7. Help customers compare products
8. Guide customers through the shopping experience

Tone: Warm, professional, helpful, and knowledgeable. Never be pushy or aggressive.

You should:
- Acknowledge the value of customer feedback
- Offer alternatives if products aren't available
- Explain our commitment to quality and purpose
- Highlight our donation initiative when relevant
- Be honest about product limitations
- Suggest related products when appropriate

You should NOT:
- Make up product information
- Promise features we don't have
- Provide pricing without confirming current rates
- Make medical or skin-related claims
- Be dismissive of customer concerns`;

/**
 * Chat with AI Assistant
 */
export async function chatWithAssistant(
  message: string,
  conversationId?: string,
  userId?: string,
  context?: {
    productId?: string;
    collectionId?: string;
    previousMessages?: Array<{ role: "user" | "assistant"; content: string }>;
  }
): Promise<{
  response: string;
  conversationId: string;
  recommendations?: string[];
}> {
  try {
    // Get or create conversation
    let conversation;

    if (conversationId) {
      conversation = await prisma.aiConversation.findUnique({
        where: { id: conversationId },
        include: { messages: { orderBy: { createdAt: "asc" } } },
      });
    }

    if (!conversation) {
      conversation = await prisma.aiConversation.create({
        data: {
          userId,
          sessionId: conversationId || `session-${Date.now()}`,
          context: context?.productId ? `product:${context.productId}` : undefined,
          messages: {
            create: [], // Will add below
          },
        },
      });
    }

    // Build message history for context
    const messageHistory = conversation.messages.map((msg) => ({
      role: msg.role as "user" | "assistant",
      content: msg.content,
    }));

    // Add context from previous messages if provided
    if (context?.previousMessages) {
      messageHistory.push(...context.previousMessages);
    }

    // Add current user message
    messageHistory.push({
      role: "user" as const,
      content: message,
    });

    // Build context prompt if product is mentioned
    let contextualSystemPrompt = SYSTEM_PROMPT;

    if (context?.productId) {
      const product = await prisma.product.findUnique({
        where: { id: context.productId },
        include: {
          images: true,
          variants: { select: { color: true, size: true, price: true } },
        },
      });

      if (product) {
        contextualSystemPrompt += `

Currently viewing product: "${product.name}"
Price: GH₵${product.price}
Materials: ${product.materials?.join(", ") || "Not specified"}
Description: ${product.description}
Available sizes: ${[...new Set(product.variants?.map((v) => v.size))].join(", ")}
Available colors: ${[...new Set(product.variants?.map((v) => v.color))].join(", ")}`;
      }
    }

    // Call OpenAI API
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: contextualSystemPrompt,
        },
        ...messageHistory,
      ],
      max_tokens: 1000,
      temperature: 0.7,
    });

    const assistantMessage =
      response.choices[0]?.message?.content || "I'm unable to respond right now.";

    // Save conversation messages
    await prisma.aiMessage.create({
      data: {
        conversationId: conversation.id,
        role: "USER",
        content: message,
      },
    });

    await prisma.aiMessage.create({
      data: {
        conversationId: conversation.id,
        role: "ASSISTANT",
        content: assistantMessage,
      },
    });

    // Extract product recommendations from response
    const recommendations = extractProductRecommendations(assistantMessage);

    return {
      response: assistantMessage,
      conversationId: conversation.id,
      recommendations,
    };
  } catch (error) {
    console.error("Error in AI assistant:", error);
    throw new Error("Failed to get AI response");
  }
}

/**
 * Extract product recommendations from AI response
 */
function extractProductRecommendations(response: string): string[] {
  // Simple extraction - looks for product names in quotes or bullet points
  const recommendations: string[] = [];

  // Match quoted product names
  const quotedMatches = response.match(/"([^"]+)"/g);
  if (quotedMatches) {
    recommendations.push(
      ...quotedMatches.map((m) => m.replace(/"/g, "")).slice(0, 3)
    );
  }

  return recommendations;
}

/**
 * Get conversation history
 */
export async function getConversationHistory(conversationId: string) {
  try {
    const conversation = await prisma.aiConversation.findUnique({
      where: { id: conversationId },
      include: {
        messages: {
          orderBy: { createdAt: "asc" },
        },
      },
    });

    if (!conversation) {
      return null;
    }

    return conversation.messages.map((msg) => ({
      id: msg.id,
      role: msg.role,
      content: msg.content,
      createdAt: msg.createdAt,
    }));
  } catch (error) {
    console.error("Error fetching conversation history:", error);
    return null;
  }
}

/**
 * Get AI product recommendations
 */
export async function getAIRecommendations(
  productId: string,
  limit: number = 5
) {
  try {
    const product = await prisma.product.findUnique({
      where: { id: productId },
      include: { images: true },
    });

    if (!product) {
      return [];
    }

    // Use OpenAI to generate recommendations based on product
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `You are a luxury fashion curator for Casa Milan Atelier. Given a product, recommend complementary items that would go well with it. Focus on loungewear that creates a cohesive collection.

Return a JSON array with the structure: [{"name": "product name", "reason": "why it complements the original product"}]`,
        },
        {
          role: "user",
          content: `Recommend items to pair with: ${product.name} (${product.materials?.join(", ")})`,
        },
      ],
      max_tokens: 500,
      temperature: 0.8,
    });

    const content = response.choices[0]?.message?.content || "[]";

    try {
      const recommendations = JSON.parse(content);
      return recommendations.slice(0, limit);
    } catch {
      return [];
    }
  } catch (error) {
    console.error("Error getting AI recommendations:", error);
    return [];
  }
}

/**
 * Generate product description with AI
 */
export async function generateProductDescription(productData: {
  name: string;
  materials: string[];
  careInstructions?: string;
}): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `You are a luxury fashion copywriter for Casa Milan Atelier. Write compelling, elegant product descriptions that emphasize comfort, quality, and luxury. Descriptions should be 2-3 sentences and suitable for a premium brand.`,
        },
        {
          role: "user",
          content: `Write a product description for: ${productData.name}
Materials: ${productData.materials.join(", ")}
${productData.careInstructions ? `Care: ${productData.careInstructions}` : ""}`,
        },
      ],
      max_tokens: 300,
      temperature: 0.7,
    });

    return response.choices[0]?.message?.content || "";
  } catch (error) {
    console.error("Error generating product description:", error);
    return "";
  }
}

/**
 * Generate marketing email with AI
 */
export async function generateMarketingEmail(
  campaignData: {
    productName: string;
    productDescription: string;
    discount?: number;
  }
): Promise<{
  subject: string;
  preheader: string;
  body: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `You are a luxury brand email copywriter for Casa Milan Atelier. Create engaging, elegant marketing emails that drive conversions while maintaining brand values.

Return a JSON object with: {"subject": "email subject", "preheader": "email preview text", "body": "email body text"}`,
        },
        {
          role: "user",
          content: `Create a marketing email for:
Product: ${campaignData.productName}
Description: ${campaignData.productDescription}
${campaignData.discount ? `Special Offer: ${campaignData.discount}% off` : ""}`,
        },
      ],
      max_tokens: 800,
      temperature: 0.8,
    });

    const content = response.choices[0]?.message?.content || "{}";

    try {
      return JSON.parse(content);
    } catch {
      return {
        subject: "Casa Milan Collection",
        preheader: "Discover luxury loungewear",
        body: "Explore our latest collection",
      };
    }
  } catch (error) {
    console.error("Error generating marketing email:", error);
    return {
      subject: "Casa Milan Collection",
      preheader: "Discover luxury loungewear",
      body: "Explore our latest collection",
    };
  }
}

/**
 * Analyze customer feedback with AI
 */
export async function analyzeFeedback(
  feedback: string
): Promise<{
  sentiment: "positive" | "negative" | "neutral";
  keywords: string[];
  summary: string;
  suggestions: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `You are a customer insights analyst for Casa Milan Atelier. Analyze customer feedback and provide actionable insights.

Return JSON: {"sentiment": "positive/negative/neutral", "keywords": ["key", "words"], "summary": "brief summary", "suggestions": ["suggested", "actions"]}`,
        },
        {
          role: "user",
          content: `Analyze this customer feedback: "${feedback}"`,
        },
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    const content = response.choices[0]?.message?.content || "{}";

    try {
      return JSON.parse(content);
    } catch {
      return {
        sentiment: "neutral",
        keywords: [],
        summary: feedback,
        suggestions: [],
      };
    }
  } catch (error) {
    console.error("Error analyzing feedback:", error);
    return {
      sentiment: "neutral",
      keywords: [],
      summary: feedback,
      suggestions: [],
    };
  }
}

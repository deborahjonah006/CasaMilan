# Casa Milan Atelier - API Architecture & Documentation

## API Overview

Casa Milan uses a RESTful API architecture built with Next.js API Routes and will support future GraphQL. All endpoints are:

- **Type-safe** with TypeScript
- **Rate-limited** to prevent abuse
- **Authenticated** with Clerk
- **Documented** with OpenAPI specs
- **Versioned** for backward compatibility
- **Error-handled** with consistent error responses

---

## API Base URLs

- **Development:** `http://localhost:3000/api`
- **Production:** `https://casamilan.com/api`
- **API Version:** `v1` (default in routes)

---

## Authentication

All API requests (except public endpoints) require authentication via Clerk:

```typescript
// Example: Using Clerk in API route
import { auth } from '@clerk/nextjs/server';

export async function GET(req: Request) {
  const { userId } = auth();
  
  if (!userId) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }
  
  // Use userId...
}
```

**Authentication Methods:**
1. **Session Cookie** - Automatic via Clerk
2. **Bearer Token** - For mobile/external apps
3. **API Key** - For third-party integrations (admin only)

---

## API Response Format

**Success Response (200, 201):**
```json
{
  "success": true,
  "data": { /* actual data */ },
  "meta": {
    "timestamp": "2025-01-20T10:30:00Z",
    "version": "1.0.0"
  }
}
```

**Error Response (4xx, 5xx):**
```json
{
  "success": false,
  "error": {
    "code": "INVALID_INPUT",
    "message": "Email is required",
    "details": {
      "field": "email",
      "reason": "missing_required_field"
    }
  },
  "meta": {
    "timestamp": "2025-01-20T10:30:00Z",
    "requestId": "req_abc123"
  }
}
```

**Paginated Response:**
```json
{
  "success": true,
  "data": [ /* items */ ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "totalPages": 8,
    "hasNextPage": true,
    "hasPreviousPage": false
  }
}
```

---

## API Endpoints

### 1. Authentication Endpoints

**POST** `/api/auth/register`
```typescript
// Register new customer
{
  "email": "customer@example.com",
  "password": "SecurePassword123!",
  "firstName": "John",
  "lastName": "Doe"
}
// Returns: { success: true, user: {...}, token: "..." }
```

**POST** `/api/auth/login`
```typescript
// Login (mostly handled by Clerk, but available for API access)
{
  "email": "customer@example.com",
  "password": "SecurePassword123!"
}
// Returns: { success: true, user: {...}, token: "..." }
```

**POST** `/api/auth/logout`
- Handles session cleanup

**POST** `/api/auth/refresh-token`
- Refreshes authentication token

**POST** `/api/auth/verify-email`
```typescript
{
  "token": "verification_token"
}
```

**POST** `/api/auth/forgot-password`
```typescript
{
  "email": "customer@example.com"
}
// Returns: { success: true, message: "Reset link sent" }
```

**POST** `/api/auth/reset-password`
```typescript
{
  "token": "reset_token",
  "password": "NewPassword123!"
}
```

---

### 2. Products Endpoints

**GET** `/api/products`
- Get paginated list of products
- Query params:
  - `page` (number) - Default: 1
  - `limit` (number) - Default: 20, Max: 100
  - `category` (string) - Filter by category slug
  - `collection` (string) - Filter by collection slug
  - `sort` (string) - `newest`, `popular`, `price_low`, `price_high`, `rating`
  - `search` (string) - Full-text search
  - `minPrice`, `maxPrice` - Price range filter
  - `colors[]` - Color filters (array)
  - `sizes[]` - Size filters (array)
  - `isFeatured` - Only featured products
  - `isBestSeller` - Only bestsellers
  - `inStock` - Only in-stock products

**GET** `/api/products/:productId`
- Get single product with full details
- Includes variants, images, reviews, recommendations

**POST** `/api/products` (Admin only)
```typescript
{
  "sku": "CM-LW-001",
  "name": "Premium Lounge Set",
  "description": "...",
  "price": 150.00,
  "currency": "GHS",
  "quantity": 100,
  "materials": ["Cotton", "Spandex"],
  "careInstructions": "...",
  "collectionId": "col_123",
  "categoryId": "cat_123",
  "seoTitle": "Premium Lounge Set",
  "seoDescription": "...",
  "images": [{ url: "...", altText: "..." }],
  "variants": [
    {
      "color": "Black",
      "size": "XS",
      "price": 150,
      "quantity": 25
    }
  ]
}
```

**PUT** `/api/products/:productId` (Admin only)
- Update product details

**DELETE** `/api/products/:productId` (Admin only)
- Archive/soft delete product

**POST** `/api/products/:productId/publish` (Admin only)
- Publish scheduled product

**GET** `/api/products/:productId/recommendations`
- Get AI-powered product recommendations

**POST** `/api/products/:productId/views`
- Track product view for analytics

---

### 3. Collections Endpoints

**GET** `/api/collections`
- Get all active collections

**GET** `/api/collections/:collectionId`
- Get collection with products

**POST** `/api/collections` (Admin only)
```typescript
{
  "name": "Summer Collection 2025",
  "slug": "summer-2025",
  "description": "...",
  "image": "...",
  "bannerImage": "...",
  "isFeatured": true,
  "seoTitle": "...",
  "seoDescription": "..."
}
```

**PUT** `/api/collections/:collectionId` (Admin only)
- Update collection

**DELETE** `/api/collections/:collectionId` (Admin only)
- Delete collection

---

### 4. Orders Endpoints

**POST** `/api/orders`
- Create new order (requires authentication or guest checkout)
```typescript
{
  "items": [
    {
      "productId": "prod_123",
      "variantId": "var_123",
      "quantity": 1,
      "price": 150.00
    }
  ],
  "shippingAddress": {
    "firstName": "John",
    "lastName": "Doe",
    "streetAddress1": "...",
    "city": "Accra",
    "region": "Greater Accra",
    "postalCode": "00100",
    "country": "GH",
    "phone": "+233..."
  },
  "billingAddress": { /* same format */ },
  "shippingMethod": "STANDARD",
  "giftWrap": false,
  "promoCode": "SAVE20",
  "loyaltyPointsToUse": 0,
  "paymentMethod": "CARD"
}
```

**GET** `/api/orders`
- Get user's orders (authenticated only)
- Query: `page`, `limit`, `status`, `dateRange`

**GET** `/api/orders/:orderId`
- Get order details with items and tracking

**POST** `/api/orders/:orderId/cancel` (Admin or customer)
- Cancel eligible order

**POST** `/api/orders/:orderId/refund` (Admin only)
```typescript
{
  "amount": 150.00,
  "reason": "Defective product"
}
```

**POST** `/api/orders/:orderId/ship` (Admin only)
```typescript
{
  "trackingNumber": "1234567890",
  "carrier": "DHL",
  "estimatedDelivery": "2025-01-25"
}
```

**GET** `/api/orders/:orderId/invoice`
- Download invoice as PDF

**POST** `/api/orders/:orderId/resend-confirmation`
- Resend order confirmation email

---

### 5. Cart Endpoints

**GET** `/api/cart`
- Get current cart

**POST** `/api/cart/add`
```typescript
{
  "productId": "prod_123",
  "variantId": "var_123",
  "quantity": 1
}
```

**PUT** `/api/cart/update`
```typescript
{
  "items": [
    { "cartItemId": "ci_123", "quantity": 2 }
  ]
}
```

**DELETE** `/api/cart/remove/:cartItemId`
- Remove item from cart

**POST** `/api/cart/clear`
- Clear entire cart

**POST** `/api/cart/validate`
- Validate cart items and pricing

**GET** `/api/cart/estimate-shipping`
- Get shipping estimates
- Query: `zipCode`, `country`

---

### 6. Checkout Endpoints

**POST** `/api/checkout/initialize`
- Initialize checkout and get payment token
```typescript
{
  "orderId": "ord_123"
}
// Returns: { accessCode: "...", authorizationUrl: "..." }
```

**GET** `/api/checkout/callback`
- Paystack callback endpoint (webhook)

**POST** `/api/checkout/confirm-payment`
- Confirm payment after callback
```typescript
{
  "reference": "paystack_reference"
}
```

---

### 7. Reviews Endpoints

**POST** `/api/products/:productId/reviews`
- Create product review (must be verified purchaser)
```typescript
{
  "rating": 5,
  "title": "Excellent quality!",
  "content": "Great product, exceeded expectations",
  "images": ["url1", "url2"]
}
```

**GET** `/api/products/:productId/reviews`
- Get product reviews
- Query: `page`, `limit`, `sort` (helpful, recent, rating)

**PUT** `/api/reviews/:reviewId` (Review author or admin)
- Update review

**DELETE** `/api/reviews/:reviewId` (Review author or admin)
- Delete review

**POST** `/api/reviews/:reviewId/helpful`
- Mark review as helpful

**POST** `/api/reviews/:reviewId/report`
- Report inappropriate review

**POST** `/api/reviews/:reviewId/respond` (Admin only)
- Respond to review

---

### 8. Wishlist Endpoints

**GET** `/api/wishlist`
- Get user's wishlists (authenticated)

**POST** `/api/wishlist`
- Create new wishlist
```typescript
{
  "name": "Spring Collection"
}
```

**POST** `/api/wishlist/:wishlistId/add`
- Add product to wishlist
```typescript
{
  "productId": "prod_123"
}
```

**DELETE** `/api/wishlist/:wishlistId/remove/:productId`
- Remove from wishlist

**GET** `/api/wishlist/:wishlistId/share`
- Get shareable wishlist (public)

**POST** `/api/wishlist/:wishlistId/notify-back-in-stock`
- Enable notification when item back in stock

---

### 9. Loyalty Endpoints

**GET** `/api/loyalty/account`
- Get user's loyalty account info

**GET** `/api/loyalty/transactions`
- Get loyalty transaction history

**POST** `/api/loyalty/redeem`
- Redeem loyalty points
```typescript
{
  "points": 100,
  "type": "discount" // or "free_shipping", etc.
}
```

**GET** `/api/loyalty/rewards`
- Get available rewards

**POST** `/api/loyalty/transfer-points`
- Transfer points to another user

---

### 10. Referral Endpoints

**GET** `/api/referral/dashboard`
- Get referral dashboard info

**GET** `/api/referral/code`
- Get user's referral code

**POST** `/api/referral/generate-link`
- Generate shareable referral link

**GET** `/api/referral/referrals`
- Get list of successful referrals

**POST** `/api/referral/claim-reward`
- Claim referral reward

---

### 11. Customer Endpoints

**GET** `/api/customers/profile`
- Get authenticated user's profile

**PUT** `/api/customers/profile`
- Update profile
```typescript
{
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+233...",
  "dateOfBirth": "1990-01-01",
  "preferredLanguage": "en",
  "preferredCurrency": "GHS"
}
```

**POST** `/api/customers/addresses`
- Add shipping address

**GET** `/api/customers/addresses`
- Get all saved addresses

**PUT** `/api/customers/addresses/:addressId`
- Update address

**DELETE** `/api/customers/addresses/:addressId`
- Delete address

**POST** `/api/customers/payment-methods`
- Save payment method

**GET** `/api/customers/payment-methods`
- Get saved payment methods

**DELETE** `/api/customers/payment-methods/:paymentMethodId`
- Remove payment method

**POST** `/api/customers/change-password`
```typescript
{
  "currentPassword": "current...",
  "newPassword": "new..."
}
```

**DELETE** `/api/customers/account`
- Delete account (requires confirmation)

---

### 12. Donations & Impact Endpoints

**GET** `/api/donations/stats`
- Get donation statistics
```json
{
  "totalDonations": 50000,
  "childrenHelped": 250,
  "orphanages": 5,
  "recentDonations": [...]
}
```

**GET** `/api/donations/timeline`
- Get donation timeline

**GET** `/api/donations/reports`
- Get annual impact reports

**POST** `/api/donations/manual` (Admin only)
- Record manual donation
```typescript
{
  "amount": 500,
  "reason": "Corporate donation",
  "date": "2025-01-20"
}
```

---

### 13. Blog & CMS Endpoints

**GET** `/api/blog/posts`
- Get published blog posts
- Query: `page`, `limit`, `category`, `tag`, `search`

**GET** `/api/blog/posts/:slug`
- Get single blog post

**POST** `/api/blog/posts` (Admin only)
```typescript
{
  "title": "...",
  "slug": "...",
  "content": "...",
  "excerpt": "...",
  "categories": ["fashion", "sustainability"],
  "tags": ["lounge", "comfort"],
  "imageUrl": "...",
  "seoTitle": "...",
  "status": "DRAFT" // or PUBLISHED, SCHEDULED
}
```

**GET** `/api/pages/:slug`
- Get CMS page content

**GET** `/api/faq`
- Get FAQ entries
- Query: `category`

---

### 14. Search Endpoints

**GET** `/api/search`
- Full-text search across products, collections, blog
```
Query params:
- q: search query
- type: product, collection, blog, faq
- page: pagination
- limit: results per page
```

**GET** `/api/search/suggestions`
- Get search suggestions based on query

**GET** `/api/search/trending`
- Get trending search terms

---

### 15. AI Assistant Endpoints

**POST** `/api/ai-assistant/chat`
- Send message to AI assistant
```typescript
{
  "message": "What size should I choose?",
  "context": {
    "productId": "prod_123",
    "conversationId": "conv_123"
  }
}
// Returns: { message: "...", recommendations: [...] }
```

**GET** `/api/ai-assistant/history/:conversationId`
- Get conversation history

**POST** `/api/ai-assistant/feedback`
- Submit feedback on AI response
```typescript
{
  "messageId": "msg_123",
  "helpful": true,
  "feedback": "..."
}
```

---

### 16. Analytics Endpoints

**POST** `/api/analytics/events`
- Track custom events
```typescript
{
  "type": "product_view",
  "productId": "prod_123",
  "category": "loungewear",
  "value": 150.00
}
```

**GET** `/api/analytics/dashboard` (Admin only)
- Get analytics dashboard data

**GET** `/api/analytics/reports/:report_type` (Admin only)
- Get specific reports
- Types: `revenue`, `products`, `customers`, `traffic`, `conversion`

---

### 17. Admin Endpoints

**POST** `/api/admin/settings`
- Update global settings (Admin only)

**GET** `/api/admin/inventory`
- Get inventory report

**POST** `/api/admin/inventory/adjust`
- Adjust stock levels

**GET** `/api/admin/customers`
- Get customer list with filters

**POST** `/api/admin/customers/:customerId/segments`
- Add customer to segment

**GET** `/api/admin/discounts`
- Get active discounts

**POST** `/api/admin/discounts`
- Create discount code

---

### 18. Notification Endpoints

**GET** `/api/notifications`
- Get user's notifications

**POST** `/api/notifications/:notificationId/read`
- Mark notification as read

**POST** `/api/notifications/preferences`
- Update notification preferences

**POST** `/api/notifications/subscribe`
- Subscribe to notifications (email, SMS, push)

---

### 19. Support Endpoints

**POST** `/api/support/tickets`
- Create support ticket
```typescript
{
  "subject": "Product quality issue",
  "description": "...",
  "category": "quality",
  "orderId": "ord_123",
  "attachments": ["url1", "url2"]
}
```

**GET** `/api/support/tickets`
- Get user's support tickets

**GET** `/api/support/tickets/:ticketId`
- Get ticket details

**POST** `/api/support/tickets/:ticketId/reply`
- Reply to ticket

**GET** `/api/support/faq`
- Search FAQ articles

---

### 20. Webhook Endpoints

**POST** `/api/webhooks/paystack`
- Paystack payment webhook (secret verification)

**POST** `/api/webhooks/clerk`
- Clerk authentication events

**POST** `/api/webhooks/custom`
- Custom business webhooks

---

## Error Codes

| Code | Status | Description |
|------|--------|-------------|
| `UNAUTHORIZED` | 401 | Authentication required |
| `FORBIDDEN` | 403 | Permission denied |
| `NOT_FOUND` | 404 | Resource not found |
| `VALIDATION_ERROR` | 400 | Invalid input |
| `CONFLICT` | 409 | Resource conflict (duplicate, etc.) |
| `RATE_LIMIT_EXCEEDED` | 429 | Too many requests |
| `PAYMENT_FAILED` | 402 | Payment processing failed |
| `SERVER_ERROR` | 500 | Internal server error |

---

## Rate Limiting

All endpoints are rate-limited:

- **Public endpoints:** 100 requests per minute
- **Authenticated endpoints:** 1000 requests per minute
- **Admin endpoints:** 500 requests per minute
- **Payment endpoints:** 50 requests per minute

Rate limit headers in response:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1705756200
```

---

## Pagination

Standard pagination format:
```
GET /api/products?page=1&limit=20

Query params:
- page: current page (default: 1)
- limit: items per page (default: 20, max: 100)
- sort: sort field
- order: ASC or DESC
```

---

## Filtering

Products support advanced filtering:
```
GET /api/products?minPrice=50&maxPrice=300&colors[]=Black&colors[]=White&sizes[]=XS&sizes[]=S
```

---

## Sorting

Supported sort options vary by endpoint. Common ones:
- `newest` / `createdAt` - Newest first
- `popular` / `views` - Most viewed
- `rating` - Highest rated
- `price_low` / `price_asc` - Lowest price first
- `price_high` / `price_desc` - Highest price first
- `name_asc` / `name_desc` - Alphabetical

---

## Security

- All endpoints use HTTPS
- CSRF protection enabled
- XSS prevention in responses
- SQL injection prevention (Prisma)
- Rate limiting per IP
- API keys in headers, never URL

---

## Versioning

Future versions will be supported:
```
/api/v1/products (current)
/api/v2/products (future)
```

Backwards compatibility maintained for 6 months after new version.

---

## Testing

Example API calls:

```bash
# Get products
curl https://casamilan.com/api/products?page=1&limit=10

# Create order (requires auth)
curl -X POST https://casamilan.com/api/orders \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "items": [...] }'

# AI Assistant
curl -X POST https://casamilan.com/api/ai-assistant/chat \
  -H "Content-Type: application/json" \
  -d '{ "message": "..." }'
```

---

## Support

- API Issues: support@casamilan.com
- Status Page: status.casamilan.com
- Documentation: docs.casamilan.com

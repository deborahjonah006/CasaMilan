// next.config.js
/** @type {import('next').NextConfig} */

const withBundleAnalyzer = require("@next/bundle-analyzer")({
  enabled: process.env.ANALYZE === "true",
});

const nextConfig = {
  // React settings
  reactStrictMode: true,
  swcMinify: true,

  // Image optimization
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "res.cloudinary.com",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
      {
        protocol: "https",
        hostname: "cdn.casamilan.com",
      },
    ],
    formats: ["image/webp", "image/avif"],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
  },

  // Domain for external images
  domains: [
    "res.cloudinary.com",
    "images.unsplash.com",
    "cdn.casamilan.com",
  ],

  // Environment variables
  env: {
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  },

  // Headers for security and performance
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          {
            key: "X-DNS-Prefetch-Control",
            value: "on",
          },
          {
            key: "X-Frame-Options",
            value: "SAMEORIGIN",
          },
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "X-XSS-Protection",
            value: "1; mode=block",
          },
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=(self)",
          },
        ],
      },
      // Cache static assets
      {
        source: "/static/:path*",
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=31536000, immutable",
          },
        ],
      },
      // Cache images
      {
        source: "/images/:path*",
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=31536000, immutable",
          },
        ],
      },
    ];
  },

  // Redirects
  async redirects() {
    return [
      {
        source: "/shop",
        destination: "/collections",
        permanent: true,
      },
      {
        source: "/journal",
        destination: "/blog",
        permanent: false,
      },
    ];
  },

  // Rewrites
  async rewrites() {
    return {
      beforeFiles: [
        {
          source: "/robots.txt",
          destination: "/api/robots",
        },
        {
          source: "/sitemap.xml",
          destination: "/api/sitemap",
        },
      ],
    };
  },

  // Webpack configuration
  webpack: (config, { isServer }) => {
    config.optimization = {
      ...config.optimization,
      splitChunks: {
        chunks: "all",
        cacheGroups: {
          default: false,
          vendors: false,
          // Vendor chunk
          vendor: {
            filename: "chunks/vendor.js",
            test: /node_modules/,
            priority: 10,
            reuseExistingChunk: true,
            name(module) {
              const packageName = module.context.match(
                /[\\/]node_modules[\\/](.*?)([\\/]|$)/
              )[1];
              return `npm.${packageName.replace("@", "")}`;
            },
          },
        },
      },
    };

    return config;
  },

  // Experimental features
  experimental: {
    // Enable optimized font loading
    optimizeFonts: true,
    // Enable optimized package imports
    optimizePackageImports: [
      "recharts",
      "date-fns",
      "lodash-es",
    ],
  },

  // Internationalization (future-ready)
  i18n: {
    locales: ["en", "es", "fr", "de", "zh"],
    defaultLocale: "en",
  },

  // Compression
  compress: true,

  // Trailing slash
  trailingSlash: false,

  // Production source maps (disable for bundle size)
  productionBrowserSourceMaps: false,

  // Powering up Next.js
  poweredByHeader: false,

  // Generate ETags
  generateEtags: true,

  // Enable Static Export (if needed)
  // output: "standalone",

  // TypeScript
  typescript: {
    tsconfigPath: "./tsconfig.json",
  },

  // ESLint
  eslint: {
    dirs: ["src"],
  },
};

module.exports = withBundleAnalyzer(nextConfig);

// src/hooks/index.ts

import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import axios from "axios";

/**
 * Hook for fetching products with filters
 */
export function useProducts(filters?: {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
  collection?: string;
  sort?: string;
  minPrice?: number;
  maxPrice?: number;
}) {
  const {
    data,
    isLoading,
    error,
    refetch,
  } = useQuery(
    ["products", filters],
    async () => {
      const params = new URLSearchParams();
      if (filters?.page) params.append("page", String(filters.page));
      if (filters?.limit) params.append("limit", String(filters.limit));
      if (filters?.search) params.append("search", filters.search);
      if (filters?.category) params.append("category", filters.category);
      if (filters?.collection) params.append("collection", filters.collection);
      if (filters?.sort) params.append("sort", filters.sort);
      if (filters?.minPrice) params.append("minPrice", String(filters.minPrice));
      if (filters?.maxPrice) params.append("maxPrice", String(filters.maxPrice));

      const response = await axios.get(`/api/products?${params.toString()}`);
      return response.data;
    },
    {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
    }
  );

  return {
    products: data?.data || [],
    pagination: data?.pagination,
    isLoading,
    error,
    refetch,
  };
}

/**
 * Hook for single product
 */
export function useProduct(productId?: string) {
  const {
    data,
    isLoading,
    error,
  } = useQuery(
    ["product", productId],
    async () => {
      const response = await axios.get(`/api/products/${productId}`);
      return response.data;
    },
    {
      enabled: !!productId,
      staleTime: 10 * 60 * 1000,
    }
  );

  return {
    product: data?.data,
    isLoading,
    error,
  };
}

/**
 * Hook for shopping cart
 */
export function useCart() {
  const queryClient = useQueryClient();

  const {
    data,
    isLoading,
  } = useQuery("cart", async () => {
    const response = await axios.get("/api/cart");
    return response.data;
  });

  const addToCart = useMutation(
    (item: { productId: string; variantId?: string; quantity: number }) => {
      return axios.post("/api/cart/add", item);
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries("cart");
      },
    }
  );

  const removeFromCart = useMutation(
    (cartItemId: string) => {
      return axios.delete(`/api/cart/remove/${cartItemId}`);
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries("cart");
      },
    }
  );

  const updateCart = useMutation(
    (items: Array<{ cartItemId: string; quantity: number }>) => {
      return axios.put("/api/cart/update", { items });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries("cart");
      },
    }
  );

  const clearCart = useMutation(
    () => axios.post("/api/cart/clear"),
    {
      onSuccess: () => {
        queryClient.invalidateQueries("cart");
      },
    }
  );

  return {
    cart: data?.data,
    items: data?.data?.items || [],
    total: data?.data?.total || 0,
    isLoading,
    addToCart: addToCart.mutate,
    removeFromCart: removeFromCart.mutate,
    updateCart: updateCart.mutate,
    clearCart: clearCart.mutate,
  };
}

/**
 * Hook for wishlist
 */
export function useWishlist() {
  const queryClient = useQueryClient();

  const {
    data,
    isLoading,
  } = useQuery(
    "wishlist",
    async () => {
      const response = await axios.get("/api/wishlist");
      return response.data;
    },
    {
      staleTime: 5 * 60 * 1000,
    }
  );

  const addToWishlist = useMutation(
    (productId: string) => {
      return axios.post("/api/wishlist/add", { productId });
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries("wishlist");
      },
    }
  );

  const removeFromWishlist = useMutation(
    (productId: string) => {
      return axios.delete(`/api/wishlist/remove/${productId}`);
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries("wishlist");
      },
    }
  );

  return {
    wishlist: data?.data,
    items: data?.data?.items || [],
    isLoading,
    addToWishlist: addToWishlist.mutate,
    removeFromWishlist: removeFromWishlist.mutate,
    isInWishlist: (productId: string) =>
      data?.data?.items?.some((item: any) => item.productId === productId) || false,
  };
}

/**
 * Hook for loyalty program
 */
export function useLoyalty() {
  const {
    data,
    isLoading,
  } = useQuery(
    "loyalty",
    async () => {
      const response = await axios.get("/api/loyalty/account");
      return response.data;
    },
    {
      staleTime: 10 * 60 * 1000,
    }
  );

  const redeemPoints = useMutation((points: number) => {
    return axios.post("/api/loyalty/redeem", { points });
  });

  return {
    account: data?.data,
    points: data?.data?.currentPoints || 0,
    tier: data?.data?.tier || "SILVER",
    isLoading,
    redeemPoints: redeemPoints.mutate,
  };
}

/**
 * Hook for customer account
 */
export function useAccount() {
  const queryClient = useQueryClient();

  const {
    data,
    isLoading,
  } = useQuery(
    "account",
    async () => {
      const response = await axios.get("/api/customers/profile");
      return response.data;
    },
    {
      staleTime: 10 * 60 * 1000,
    }
  );

  const updateProfile = useMutation(
    (profile: any) => {
      return axios.put("/api/customers/profile", profile);
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries("account");
      },
    }
  );

  const changePassword = useMutation((passwords: {
    currentPassword: string;
    newPassword: string;
  }) => {
    return axios.post("/api/customers/change-password", passwords);
  });

  return {
    user: data?.data,
    isLoading,
    updateProfile: updateProfile.mutate,
    changePassword: changePassword.mutate,
  };
}

/**
 * Hook for orders
 */
export function useOrders() {
  const {
    data,
    isLoading,
    refetch,
  } = useQuery(
    "orders",
    async () => {
      const response = await axios.get("/api/orders");
      return response.data;
    },
    {
      staleTime: 5 * 60 * 1000,
    }
  );

  return {
    orders: data?.data || [],
    isLoading,
    refetch,
  };
}

/**
 * Hook for AI chat
 */
export function useAIChat(conversationId?: string) {
  const [messages, setMessages] = useState<Array<{
    id: string;
    role: "user" | "assistant";
    content: string;
  }>>([]);

  const sendMessage = useMutation(
    (message: string) => {
      return axios.post("/api/ai-assistant/chat", {
        message,
        conversationId,
      });
    },
    {
      onSuccess: (data) => {
        setMessages((prev) => [
          ...prev,
          { id: "user-" + Date.now(), role: "user", content: data.config.data.message },
          { id: "ai-" + Date.now(), role: "assistant", content: data.data.response },
        ]);
      },
    }
  );

  return {
    messages,
    sendMessage: sendMessage.mutate,
    isLoading: sendMessage.isLoading,
    conversationId: conversationId,
  };
}

/**
 * Hook for detecting mobile device
 */
export function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  return isMobile;
}

/**
 * Hook for local storage
 */
export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = typeof window !== "undefined" ? window.localStorage.getItem(key) : null;
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value: T) => {
      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value;
        setStoredValue(valueToStore);
        if (typeof window !== "undefined") {
          window.localStorage.setItem(key, JSON.stringify(valueToStore));
        }
      } catch (error) {
        console.error(error);
      }
    },
    [key, storedValue]
  );

  return [storedValue, setValue];
}

/**
 * Hook for debounced input
 */
export function useDebouncedValue<T>(value: T, delay: number = 500): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

/**
 * Hook for tracking analytics
 */
export function useAnalytics() {
  const trackEvent = useCallback((eventName: string, eventData?: any) => {
    // Track with Google Analytics
    if (typeof window !== "undefined" && (window as any).gtag) {
      (window as any).gtag("event", eventName, eventData);
    }
  }, []);

  return {
    trackEvent,
  };
}

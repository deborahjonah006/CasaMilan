// src/lib/auth.ts
import { auth, currentUser } from "@clerk/nextjs/server";
import { prisma } from "./prisma";
import { Role } from "@prisma/client";

/**
 * Get authenticated user with full profile
 */
export async function getAuthenticatedUser() {
  const { userId } = auth();

  if (!userId) {
    return null;
  }

  try {
    const user = await prisma.user.findUnique({
      where: { clerkId: userId },
      include: {
        customer: true,
        adminRoles: true,
        loyaltyAccount: true,
      },
    });

    return user;
  } catch (error) {
    console.error("Error fetching user:", error);
    return null;
  }
}

/**
 * Require authentication (throw error if not authenticated)
 */
export async function requireAuth() {
  const user = await getAuthenticatedUser();

  if (!user) {
    throw new Error("Authentication required");
  }

  return user;
}

/**
 * Check if user has specific role
 */
export async function hasRole(role: "ADMIN" | "SUPER_ADMIN" | "CUSTOMER") {
  const user = await getAuthenticatedUser();

  if (!user) {
    return false;
  }

  if (role === "CUSTOMER") {
    return user.role === "CUSTOMER";
  }

  return user.adminRoles.some((adminRole) => adminRole.role === role);
}

/**
 * Require admin role
 */
export async function requireAdmin() {
  const isAdmin = await hasRole("ADMIN");

  if (!isAdmin) {
    throw new Error("Admin access required");
  }

  return await requireAuth();
}

/**
 * Require super admin role
 */
export async function requireSuperAdmin() {
  const isSuperAdmin = await hasRole("SUPER_ADMIN");

  if (!isSuperAdmin) {
    throw new Error("Super admin access required");
  }

  return await requireAuth();
}

/**
 * Check if user has specific permission
 */
export async function hasPermission(permission: string): Promise<boolean> {
  const user = await getAuthenticatedUser();

  if (!user) {
    return false;
  }

  if (user.role === "SUPER_ADMIN") {
    return true; // Super admins have all permissions
  }

  const adminRole = user.adminRoles[0];

  if (!adminRole) {
    return false;
  }

  return adminRole.permissions.includes(permission);
}

/**
 * Sync Clerk user to database
 */
export async function syncClerkUser(clerkUserId: string) {
  const clerkUser = await currentUser();

  if (!clerkUser) {
    throw new Error("User not found in Clerk");
  }

  const user = await prisma.user.upsert({
    where: { clerkId: clerkUserId },
    update: {
      email: clerkUser.emailAddresses[0]?.emailAddress || "",
      firstName: clerkUser.firstName || undefined,
      lastName: clerkUser.lastName || undefined,
      avatar: clerkUser.imageUrl || undefined,
    },
    create: {
      clerkId: clerkUserId,
      email: clerkUser.emailAddresses[0]?.emailAddress || "",
      firstName: clerkUser.firstName || undefined,
      lastName: clerkUser.lastName || undefined,
      avatar: clerkUser.imageUrl || undefined,
      role: "CUSTOMER",
      status: "ACTIVE",
    },
  });

  // Create customer profile if doesn't exist
  if (!user.id) {
    await prisma.customer.create({
      data: {
        userId: user.id,
      },
    });
  }

  return user;
}

/**
 * Create admin user (Super admin only)
 */
export async function createAdminUser(
  email: string,
  adminRole: string,
  permissions: string[]
) {
  const isSuperAdmin = await hasRole("SUPER_ADMIN");

  if (!isSuperAdmin) {
    throw new Error("Only super admins can create admin users");
  }

  // First create or update user
  let user = await prisma.user.findUnique({
    where: { email },
  });

  if (!user) {
    user = await prisma.user.create({
      data: {
        email,
        role: "ADMIN",
        status: "ACTIVE",
      },
    });
  }

  // Create admin role
  await prisma.adminRole.upsert({
    where: { userId_role: { userId: user.id, role: adminRole as any } },
    update: { permissions },
    create: {
      userId: user.id,
      role: adminRole as any,
      permissions,
    },
  });

  return user;
}

/**
 * Log admin action
 */
export async function logAdminAction(
  action: string,
  entityType: string,
  entityId: string,
  changes?: any
) {
  const user = await getAuthenticatedUser();

  if (!user) {
    return;
  }

  await prisma.auditLog.create({
    data: {
      userId: user.id,
      action,
      entityType,
      entityId,
      changes,
      ipAddress: "127.0.0.1", // Get from request headers in real implementation
    },
  });
}

/**
 * Record login attempt
 */
export async function recordLoginAttempt(
  email: string,
  isSuccessful: boolean,
  ipAddress?: string
) {
  const user = await prisma.user.findUnique({
    where: { email },
  });

  if (!user) {
    return;
  }

  if (isSuccessful) {
    await prisma.user.update({
      where: { id: user.id },
      data: {
        lastLoginAt: new Date(),
        lastLoginIp: ipAddress,
        loginAttempts: 0,
      },
    });
  } else {
    // Increment failed attempts
    const attempts = (user.loginAttempts || 0) + 1;

    await prisma.user.update({
      where: { id: user.id },
      data: {
        loginAttempts: attempts,
        // Lock account after 5 failed attempts for 30 minutes
        lockedUntil:
          attempts >= 5
            ? new Date(Date.now() + 30 * 60 * 1000)
            : user.lockedUntil,
      },
    });
  }

  await prisma.loginHistory.create({
    data: {
      userId: user.id,
      ipAddress: ipAddress || "unknown",
      userAgent: "user-agent-placeholder",
      deviceType: "web",
      isSuccessful,
    },
  });
}

/**
 * Check if account is locked
 */
export async function isAccountLocked(email: string): Promise<boolean> {
  const user = await prisma.user.findUnique({
    where: { email },
  });

  if (!user || !user.lockedUntil) {
    return false;
  }

  if (user.lockedUntil > new Date()) {
    return true;
  }

  // Unlock if time has passed
  await prisma.user.update({
    where: { id: user.id },
    data: { lockedUntil: null },
  });

  return false;
}

/**
 * Get user's session info
 */
export async function getSessionInfo() {
  const { userId, sessionId } = auth();

  if (!userId) {
    return null;
  }

  const user = await getAuthenticatedUser();

  return {
    userId,
    sessionId,
    user,
    authenticated: true,
  };
}

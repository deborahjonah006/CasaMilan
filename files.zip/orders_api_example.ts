// src/app/api/orders/route.ts
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAuthenticatedUser, logAdminAction } from "@/lib/auth";
import { formatPrice } from "@/lib/utils";
import { sendOrderConfirmationEmail } from "@/lib/email";

// Schema for order creation
const CreateOrderSchema = z.object({
  items: z.array(
    z.object({
      productId: z.string(),
      variantId: z.string().optional(),
      quantity: z.number().int().positive(),
    })
  ),
  shippingAddress: z.object({
    firstName: z.string(),
    lastName: z.string(),
    streetAddress1: z.string(),
    streetAddress2: z.string().optional(),
    city: z.string(),
    region: z.string(),
    postalCode: z.string(),
    country: z.string(),
    phone: z.string(),
  }),
  billingAddress: z.object({
    firstName: z.string(),
    lastName: z.string(),
    streetAddress1: z.string(),
    streetAddress2: z.string().optional(),
    city: z.string(),
    region: z.string(),
    postalCode: z.string(),
    country: z.string(),
    phone: z.string(),
  }).optional(),
  shippingMethod: z.enum(["STANDARD", "EXPRESS", "PICKUP"]),
  paymentMethod: z.enum(["CARD", "BANK_TRANSFER", "MOBILE_MONEY", "WALLET"]),
  giftWrap: z.boolean().default(false),
  giftMessage: z.string().optional(),
  promoCode: z.string().optional(),
  loyaltyPointsToUse: z.number().int().nonnegative().default(0),
});

type CreateOrderInput = z.infer<typeof CreateOrderSchema>;

/**
 * POST /api/orders
 * Create new order
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // Validate input
    const parsed = CreateOrderSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          success: false,
          error: "Validation failed",
          details: parsed.error.flatten(),
        },
        { status: 400 }
      );
    }

    const orderData = parsed.data;
    const user = await getAuthenticatedUser();
    const customerEmail = user?.email || orderData.shippingAddress.firstName;

    // Get or create cart items with pricing
    let subtotal = 0;
    const orderItems = [];

    for (const item of orderData.items) {
      const product = await prisma.product.findUnique({
        where: { id: item.productId },
        include: { variants: true },
      });

      if (!product) {
        return NextResponse.json(
          {
            success: false,
            error: `Product ${item.productId} not found`,
          },
          { status: 404 }
        );
      }

      // Get variant or base product pricing
      let price = product.salePrice || product.price;
      let compareAtPrice = product.compareAtPrice;

      if (item.variantId) {
        const variant = product.variants.find((v) => v.id === item.variantId);
        if (variant) {
          price = variant.salePrice || variant.price || price;
        }
      }

      // Check inventory
      if (product.quantity < item.quantity) {
        return NextResponse.json(
          {
            success: false,
            error: `Insufficient inventory for ${product.name}`,
          },
          { status: 409 }
        );
      }

      const itemTotal = price * item.quantity;
      subtotal += itemTotal;

      orderItems.push({
        productId: item.productId,
        variantId: item.variantId,
        quantity: item.quantity,
        price,
        compareAtPrice,
      });
    }

    // Apply promo code if provided
    let discountAmount = 0;
    let promoCodeId: string | undefined;

    if (orderData.promoCode) {
      const promo = await prisma.promoCode.findUnique({
        where: { code: orderData.promoCode },
      });

      if (promo && promo.isActive) {
        if (promo.validFrom > new Date() || promo.validUntil < new Date()) {
          return NextResponse.json(
            { success: false, error: "Promo code expired" },
            { status: 400 }
          );
        }

        if (subtotal < (promo.minPurchaseAmount || 0)) {
          return NextResponse.json(
            { success: false, error: "Order amount too low for promo" },
            { status: 400 }
          );
        }

        if (promo.discountType === "PERCENTAGE") {
          discountAmount = (subtotal * promo.discountValue) / 100;
          if (promo.maxDiscount) {
            discountAmount = Math.min(discountAmount, promo.maxDiscount);
          }
        } else if (promo.discountType === "FIXED_AMOUNT") {
          discountAmount = promo.discountValue;
        }

        promoCodeId = promo.id;
      }
    }

    // Calculate shipping
    const shippingZone = await prisma.deliveryZone.findFirst({
      where: {
        regions: { hasSome: [orderData.shippingAddress.region] },
        isActive: true,
      },
    });

    const shippingCost = shippingZone?.baseShippingCost || 50; // Default shipping

    // Calculate tax (simplified - would vary by location)
    const taxRate = 0.05; // 5% tax
    const taxAmount = (subtotal - discountAmount) * taxRate;

    // Total
    const total = subtotal - discountAmount + taxAmount + shippingCost;

    // Generate order number
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Create order in database
    const order = await prisma.order.create({
      data: {
        orderNumber,
        userId: user?.id,
        customerEmail,
        customerPhone: orderData.shippingAddress.phone,
        items: {
          create: orderItems.map((item) => ({
            productId: item.productId,
            variantId: item.variantId,
            quantity: item.quantity,
            price: item.price,
            compareAtPrice: item.compareAtPrice,
            subtotal: item.price * item.quantity,
          })),
        },
        shippingAddress: orderData.shippingAddress,
        billingAddress: orderData.billingAddress || orderData.shippingAddress,
        shippingMethod: orderData.shippingMethod,
        shippingCost,
        shippingStatus: "PENDING",
        subtotal,
        taxAmount,
        discountAmount,
        total,
        promoCodeId,
        paymentMethod: orderData.paymentMethod,
        paymentStatus: "PENDING",
        status: "PENDING",
        giftWrap: orderData.giftWrap,
        giftMessage: orderData.giftMessage,
      },
      include: {
        items: { include: { product: true } },
        statusHistory: true,
      },
    });

    // Reduce product inventory
    for (const item of orderItems) {
      await prisma.product.update({
        where: { id: item.productId },
        data: { quantity: { decrement: item.quantity } },
      });
    }

    // Record donation
    const donationAmount = orderItems.length * 0.5; // 50 pesewas per item
    await prisma.donationRecord.create({
      data: {
        orderId: order.id,
        amount: donationAmount,
        type: "PURCHASE",
        status: "PENDING",
      },
    });

    // Add loyalty points
    if (user) {
      const loyaltyAccount = await prisma.loyaltyAccount.findUnique({
        where: { userId: user.id },
      });

      if (loyaltyAccount) {
        const pointsEarned = Math.floor(subtotal / 100) * 10; // 10 points per GHS 100

        await prisma.loyaltyAccount.update({
          where: { id: loyaltyAccount.id },
          data: {
            currentPoints: { increment: pointsEarned },
            lifetimePoints: { increment: pointsEarned },
          },
        });

        await prisma.loyaltyTransaction.create({
          data: {
            loyaltyAccountId: loyaltyAccount.id,
            type: "EARN",
            points: pointsEarned,
            reason: `Purchase order ${orderNumber}`,
            orderId: order.id,
            balanceBefore: loyaltyAccount.currentPoints,
            balanceAfter: loyaltyAccount.currentPoints + pointsEarned,
          },
        });
      }
    }

    // Send confirmation email
    await sendOrderConfirmationEmail(order);

    return NextResponse.json(
      {
        success: true,
        data: {
          orderId: order.id,
          orderNumber: order.orderNumber,
          total: order.total,
          status: order.status,
          paymentStatus: order.paymentStatus,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating order:", error);
    return NextResponse.json(
      { success: false, error: "Failed to create order" },
      { status: 500 }
    );
  }
}

/**
 * GET /api/orders
 * Get user's orders
 */
export async function GET(req: NextRequest) {
  try {
    const user = await getAuthenticatedUser();

    if (!user) {
      return NextResponse.json(
        { success: false, error: "Authentication required" },
        { status: 401 }
      );
    }

    const searchParams = req.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(50, parseInt(searchParams.get("limit") || "10"));
    const status = searchParams.get("status");

    const where: any = { userId: user.id };

    if (status) {
      where.status = status;
    }

    const total = await prisma.order.count({ where });

    const orders = await prisma.order.findMany({
      where,
      include: {
        items: { include: { product: { select: { name: true, images: true } } } },
        statusHistory: { orderBy: { createdAt: "desc" } },
      },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * limit,
      take: limit,
    });

    return NextResponse.json({
      success: true,
      data: orders,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Error fetching orders:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch orders" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/orders/:orderId/initiate-payment
 * Initialize payment with Paystack
 */
export async function initiatePayment(orderId: string) {
  try {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new Error("Order not found");
    }

    // Call Paystack API to initialize transaction
    const paystackResponse = await fetch(
      "https://api.paystack.co/transaction/initialize",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: order.customerEmail,
          amount: Math.round(order.total * 100), // Paystack uses kobo
          metadata: {
            orderId: order.id,
            orderNumber: order.orderNumber,
          },
        }),
      }
    );

    const data = await paystackResponse.json();

    if (!data.status) {
      throw new Error(data.message);
    }

    // Store payment reference
    await prisma.payment.create({
      data: {
        orderId: order.id,
        amount: order.total,
        status: "PENDING",
        method: order.paymentMethod,
        reference: data.data.reference,
        accessCode: data.data.access_code,
        authorizationUrl: data.data.authorization_url,
        payerEmail: order.customerEmail,
      },
    });

    return {
      success: true,
      authorizationUrl: data.data.authorization_url,
      accessCode: data.data.access_code,
      reference: data.data.reference,
    };
  } catch (error) {
    console.error("Error initiating payment:", error);
    throw error;
  }
}

/**
 * Verify Paystack payment
 */
export async function verifyPaystackPayment(reference: string) {
  try {
    const response = await fetch(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        },
      }
    );

    const data = await response.json();

    if (!data.status || data.data.status !== "success") {
      throw new Error("Payment verification failed");
    }

    return data.data;
  } catch (error) {
    console.error("Error verifying payment:", error);
    throw error;
  }
}

// src/app/api/products/route.ts
import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { hasRole } from "@/lib/auth";
import { generateSlug } from "@/lib/utils";

// Schema for product creation/update
const CreateProductSchema = z.object({
  sku: z.string().min(1).max(100),
  name: z.string().min(1).max(255),
  subtitle: z.string().max(255).optional(),
  description: z.string().optional(),
  shortDescription: z.string().optional(),
  price: z.number().positive(),
  compareAtPrice: z.number().positive().optional(),
  salePrice: z.number().positive().optional(),
  quantity: z.number().int().nonnegative().default(0),
  materials: z.array(z.string()).default([]),
  careInstructions: z.string().optional(),
  collectionId: z.string().optional(),
  categoryId: z.string().optional(),
  tags: z.array(z.string()).default([]),
  seoTitle: z.string().optional(),
  seoDescription: z.string().optional(),
  seoKeywords: z.array(z.string()).default([]),
});

type CreateProductInput = z.infer<typeof CreateProductSchema>;

/**
 * GET /api/products
 * Get paginated products with filters
 */
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(100, parseInt(searchParams.get("limit") || "20"));
    const sort = searchParams.get("sort") || "newest";
    const category = searchParams.get("category");
    const collection = searchParams.get("collection");
    const search = searchParams.get("search");
    const minPrice = searchParams.get("minPrice");
    const maxPrice = searchParams.get("maxPrice");
    const isFeatured = searchParams.get("isFeatured") === "true";
    const isBestSeller = searchParams.get("isBestSeller") === "true";
    const inStock = searchParams.get("inStock") === "true";

    // Build where clause
    const where: any = {
      status: "PUBLISHED",
      publishedAt: { lte: new Date() },
    };

    if (category) {
      const cat = await prisma.category.findUnique({
        where: { slug: category },
      });
      if (cat) where.categoryId = cat.id;
    }

    if (collection) {
      const coll = await prisma.collection.findUnique({
        where: { slug: collection },
      });
      if (coll) where.collectionId = coll.id;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { shortDescription: { contains: search, mode: "insensitive" } },
      ];
    }

    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = parseFloat(minPrice);
      if (maxPrice) where.price.lte = parseFloat(maxPrice);
    }

    if (isFeatured) where.isFeatured = true;
    if (isBestSeller) where.isBestSeller = true;
    if (inStock) where.quantity = { gt: 0 };

    // Build orderBy
    let orderBy: any = { createdAt: "desc" };
    switch (sort) {
      case "popular":
        orderBy = { views: "desc" };
        break;
      case "price_low":
        orderBy = { price: "asc" };
        break;
      case "price_high":
        orderBy = { price: "desc" };
        break;
      case "rating":
        // Would need average rating calculated
        orderBy = { createdAt: "desc" };
        break;
      case "name":
        orderBy = { name: "asc" };
        break;
    }

    // Get total count
    const total = await prisma.product.count({ where });

    // Get products
    const products = await prisma.product.findMany({
      where,
      include: {
        images: { where: { isDisplayImage: true }, take: 1 },
        variants: {
          where: { quantity: { gt: 0 } },
          select: {
            id: true,
            color: true,
            size: true,
            price: true,
          },
          distinct: ["color", "size"],
        },
        _count: {
          select: { reviews: true },
        },
      },
      orderBy,
      skip: (page - 1) * limit,
      take: limit,
    });

    return NextResponse.json({
      success: true,
      data: products,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNextPage: page < Math.ceil(total / limit),
        hasPreviousPage: page > 1,
      },
      meta: {
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Error fetching products:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/products
 * Create new product (Admin only)
 */
export async function POST(req: NextRequest) {
  try {
    // Check admin role
    const isAdmin = await hasRole("ADMIN");
    if (!isAdmin) {
      return NextResponse.json(
        { success: false, error: "Admin access required" },
        { status: 403 }
      );
    }

    const body = await req.json();

    // Validate input
    const parsed = CreateProductSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          success: false,
          error: "Validation failed",
          details: parsed.error.flatten(),
        },
        { status: 400 }
      );
    }

    const data = parsed.data;

    // Check SKU uniqueness
    const existingSku = await prisma.product.findUnique({
      where: { sku: data.sku },
    });

    if (existingSku) {
      return NextResponse.json(
        { success: false, error: "SKU already exists" },
        { status: 409 }
      );
    }

    // Create product
    const product = await prisma.product.create({
      data: {
        ...data,
        slug: generateSlug(data.name),
        publishedAt: new Date(),
        updatedAt: new Date(),
      },
      include: {
        images: true,
        variants: true,
      },
    });

    return NextResponse.json(
      { success: true, data: product },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating product:", error);
    return NextResponse.json(
      { success: false, error: "Failed to create product" },
      { status: 500 }
    );
  }
}

/**
 * GET /api/products/:productId
 * Get single product with full details
 */
export async function getProduct(productId: string) {
  try {
    const product = await prisma.product.findUnique({
      where: { id: productId },
      include: {
        images: { orderBy: { position: "asc" } },
        videos: { orderBy: { position: "asc" } },
        variants: {
          orderBy: { id: "asc" },
          include: { images: true },
        },
        reviews: {
          where: { status: "APPROVED" },
          include: {
            user: { select: { firstName: true, lastName: true, avatar: true } },
            media: true,
          },
          orderBy: { createdAt: "desc" },
          take: 10,
        },
        relatedProducts: {
          include: { relatedProduct: { include: { images: true } } },
        },
        frequentlyBoughtTogether: {
          include: { boughtWithProduct: { include: { images: true } } },
          orderBy: { frequency: "desc" },
          take: 5,
        },
        collection: { select: { id: true, name: true, slug: true } },
        category: { select: { id: true, name: true, slug: true } },
        _count: {
          select: {
            reviews: true,
            wishlistItems: true,
            orderItems: true,
          },
        },
      },
    });

    if (!product || product.status !== "PUBLISHED") {
      return null;
    }

    return product;
  } catch (error) {
    console.error("Error fetching product:", error);
    return null;
  }
}

/**
 * Track product view
 */
export async function trackProductView(productId: string, ipAddress: string) {
  try {
    // Increment view count
    await prisma.product.update({
      where: { id: productId },
      data: { views: { increment: 1 } },
    });

    // Log analytics event
    await prisma.analyticsEvent.create({
      data: {
        type: "product_view",
        productId,
        sessionId: ipAddress, // Simplified - use session ID in real implementation
        pageUrl: `/products/${productId}`,
        deviceType: "web",
      },
    });
  } catch (error) {
    console.error("Error tracking product view:", error);
  }
}

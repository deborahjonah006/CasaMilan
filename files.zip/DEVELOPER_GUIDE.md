# Casa Milan - Developer Quick Reference

Quick reference guide for common development tasks.

---

## 🚀 Essential Commands

```bash
# Development
pnpm dev                    # Start dev server
pnpm build                  # Build for production
pnpm start                  # Run production server
pnpm test                   # Run tests
pnpm lint                   # Run linter
pnpm type-check            # Check TypeScript types
pnpm format                # Format code with Prettier

# Database
pnpm db:generate           # Generate Prisma client
pnpm db:push              # Push schema to database
pnpm db:migrate           # Create migration
pnpm db:seed              # Seed initial data
pnpm db:reset             # ⚠️ Drop and recreate database
pnpm db:studio            # Open Prisma Studio GUI

# Cleanup
pnpm clean                # Clean build artifacts
pnpm install              # Reinstall dependencies
```

---

## 📝 Code Style Guide

### TypeScript

```typescript
// Always use type annotations
const user: User = { ... };

// Use type-safe database queries
const product = await prisma.product.findUnique({
  where: { id: "prod_123" },
  include: { images: true, variants: true }
});

// Use zod for validation
const CreateProductSchema = z.object({
  name: z.string().min(1).max(100),
  price: z.number().positive(),
  description: z.string().optional(),
});
```

### React Components

```typescript
// Use functional components with TypeScript
interface ProductCardProps {
  product: Product;
  onAddToCart: (productId: string) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <div className="...">
      {/* Component content */}
    </div>
  );
}
```

### Styling

```typescript
// Use Tailwind CSS with cn() utility
import { cn } from "@/lib/utils";

export function Button({ variant, ...props }: ButtonProps) {
  return (
    <button
      className={cn(
        "px-4 py-2 rounded-lg font-medium",
        variant === "primary" && "bg-gold-500 text-white",
        variant === "secondary" && "bg-ivory-100 text-charcoal-800"
      )}
      {...props}
    />
  );
}
```

### File Organization

```
src/
  app/
    (shop)/
      page.tsx              # Route component
      layout.tsx            # Route layout
      error.tsx             # Error boundary
      not-found.tsx         # 404 page
  components/
    shop/
      ProductCard.tsx       # Component (PascalCase)
      ProductCard.types.ts  # Component types
      ProductCard.module.css # Scoped styles (if needed)
  lib/
    utils.ts               # Utility functions
  types/
    index.ts               # TypeScript definitions
```

---

## 🗄️ Database Best Practices

### Prisma Queries

```typescript
// ✅ Good: Specific fields, optimized
const users = await prisma.user.findMany({
  where: { status: "ACTIVE" },
  select: { id: true, email: true, firstName: true },
  take: 20,
  orderBy: { createdAt: "desc" }
});

// ❌ Bad: Fetching entire objects
const users = await prisma.user.findMany();

// ✅ Good: Use include for relationships
const order = await prisma.order.findUnique({
  where: { id: "ord_123" },
  include: {
    items: true,
    customer: true,
    payments: true
  }
});

// ❌ Bad: Multiple queries for relationships
const order = await prisma.order.findUnique({ where: { id: "ord_123" } });
const items = await prisma.orderItem.findMany({ where: { orderId: order.id } });
```

### Transactions

```typescript
// Atomic operations
const result = await prisma.$transaction(async (tx) => {
  const order = await tx.order.create({ data: {...} });
  await tx.loyaltyAccount.update({
    where: { userId: order.userId },
    data: { currentPoints: { increment: 100 } }
  });
  return order;
});
```

### Migrations

```bash
# Create migration
pnpm db:migrate

# Name it descriptively:
# 20250120_add_product_variants
# 20250121_create_loyalty_system

# Review generated migration file
# Modify if needed
# Run it
pnpm db:push
```

---

## 🔐 API Development

### Creating Endpoints

```typescript
// src/app/api/products/route.ts
import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");

    const products = await prisma.product.findMany({
      where: { status: "PUBLISHED" },
      take: limit,
      skip: (page - 1) * limit,
      orderBy: { createdAt: "desc" }
    });

    return NextResponse.json({
      success: true,
      data: products,
      pagination: { page, limit, total: products.length }
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  const { userId } = auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();

  // Validate input
  const parsed = CreateProductSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const product = await prisma.product.create({
    data: parsed.data
  });

  return NextResponse.json({ success: true, data: product }, { status: 201 });
}
```

### Error Handling

```typescript
// Create API errors consistently
export class ApiError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string
  ) {
    super(message);
  }
}

// In route handlers
try {
  // ...
} catch (error) {
  if (error instanceof ApiError) {
    return NextResponse.json(
      { error: { code: error.code, message: error.message } },
      { status: error.statusCode }
    );
  }
  
  return NextResponse.json(
    { error: "Internal server error" },
    { status: 500 }
  );
}
```

---

## 🎨 Component Development

### Creating Reusable Components

```typescript
// Good component structure
export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
  isLoading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = "primary",
      size = "md",
      isLoading = false,
      disabled,
      ...props
    },
    ref
  ) => (
    <button
      ref={ref}
      disabled={disabled || isLoading}
      className={cn(
        "font-button transition-colors",
        // Size variants
        size === "sm" && "px-3 py-1 text-sm",
        size === "md" && "px-4 py-2 text-base",
        size === "lg" && "px-6 py-3 text-lg",
        // Color variants
        variant === "primary" && "bg-gold-500 text-white hover:bg-gold-600",
        variant === "secondary" && "bg-ivory-100 text-charcoal-800",
        variant === "ghost" && "hover:bg-ivory-50",
        // Disabled state
        disabled && "opacity-50 cursor-not-allowed",
        className
      )}
      {...props}
    >
      {isLoading ? <Spinner /> : props.children}
    </button>
  )
);
Button.displayName = "Button";
```

### Using Hooks

```typescript
// Use custom hooks for complex logic
function ProductList() {
  const { products, isLoading, error, refetch } = useProducts({
    category: "loungewear",
    sortBy: "newest"
  });

  if (isLoading) return <ProductSkeleton />;
  if (error) return <ErrorMessage error={error} />;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
```

---

## 🧪 Testing

```typescript
// Unit test example
import { formatPrice } from "@/lib/utils";

describe("formatPrice", () => {
  it("should format price with currency", () => {
    expect(formatPrice(150.5, "GHS")).toBe("GH₵ 150.50");
  });

  it("should handle zero", () => {
    expect(formatPrice(0, "USD")).toBe("$0.00");
  });
});

// Component test example
import { render, screen } from "@testing-library/react";
import { ProductCard } from "@/components/shop/ProductCard";

describe("ProductCard", () => {
  it("renders product name", () => {
    const product = { id: "1", name: "Premium Set", price: 150 };
    render(<ProductCard product={product} />);
    expect(screen.getByText("Premium Set")).toBeInTheDocument();
  });
});
```

---

## 🚀 Deployment Checklist

Before deploying to production:

- [ ] All tests pass: `pnpm test`
- [ ] No lint errors: `pnpm lint`
- [ ] Types check: `pnpm type-check`
- [ ] Build succeeds: `pnpm build`
- [ ] Database migrations reviewed
- [ ] Environment variables set in Vercel
- [ ] Paystack webhook configured
- [ ] Error tracking (Sentry) configured
- [ ] Analytics pixels added
- [ ] SSL certificate valid
- [ ] Backups configured
- [ ] Monitoring alerts set up

---

## 🔍 Debugging Tips

### Console Logging
```typescript
// Use debug logs
console.log("[PRODUCT_FETCH]", { productId, timestamp: new Date() });

// Never commit console.logs in production
if (process.env.NODE_ENV === "development") {
  console.log("Debug info");
}
```

### Network Requests
```typescript
// Check network tab in browser DevTools
// Check API responses in Vercel Logs
// Use curl to test endpoints
curl https://casamilan.com/api/products -H "Authorization: Bearer $TOKEN"
```

### Database Debugging
```bash
# Open Prisma Studio
pnpm db:studio

# Check raw queries
# Enable logging in .env.local
DEBUG=prisma:*
```

---

## 📦 Dependencies Management

```bash
# Add dependency
pnpm add package-name

# Add dev dependency
pnpm add -D package-name

# Update dependencies
pnpm update

# Check for outdated
pnpm outdated

# Remove unused
pnpm prune
```

---

## 🌍 Environment Variables in Development

Create `.env.local` for local development:

```env
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/casa_milan
DIRECT_URL=postgresql://user:pass@localhost:5432/casa_milan

# Clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...

# Payment
PAYSTACK_SECRET_KEY=sk_test_...

# AI
OPENAI_API_KEY=sk_...

# Storage
CLOUDINARY_API_KEY=...
```

Never commit `.env.local` to Git!

---

## 🐛 Common Issues & Solutions

### "Module not found" error
```bash
# Clear cache and reinstall
pnpm clean
rm -rf node_modules
pnpm install
pnpm db:generate
```

### Database connection error
```bash
# Check connection string
echo $DATABASE_URL

# Verify database exists
psql -l

# Create if missing
createdb casa_milan
```

### Type errors after schema change
```bash
# Regenerate Prisma client
pnpm db:generate

# Restart dev server
# Ctrl+C and pnpm dev
```

### Build fails in Vercel
- Check all env vars are set
- Verify database migrations completed
- Check Vercel build logs in detail
- Test build locally: `pnpm build`

---

## 📚 Resources

- **Next.js Docs** — https://nextjs.org/docs
- **Prisma Docs** — https://www.prisma.io/docs
- **Tailwind Docs** — https://tailwindcss.com/docs
- **TypeScript Docs** — https://www.typescriptlang.org/docs
- **React Docs** — https://react.dev
- **Clerk Docs** — https://clerk.com/docs

---

## 💡 Tips

1. **Use TypeScript** — Catch errors at compile time
2. **Test locally** — Test features before pushing
3. **Keep commits small** — Easier to revert if needed
4. **Use feature branches** — Never work on main
5. **Review code** — Peer review before merging
6. **Document changes** — Update README when needed
7. **Monitor logs** — Check Vercel logs for errors
8. **Back up data** — Regular database backups

---

**Happy coding! 🚀**

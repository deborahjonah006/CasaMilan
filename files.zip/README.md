# Casa Milan Atelier - Luxury Loungewear E-Commerce Platform

> **Luxury with Purpose** — A world-class luxury loungewear e-commerce platform with social impact, built for enterprise-grade scalability, performance, and elegance.

[![Next.js](https://img.shields.io/badge/Next.js-14-black)](https://nextjs.org)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)](https://www.typescriptlang.org)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-14+-336791)](https://www.postgresql.org)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3-38B2AC)](https://tailwindcss.com)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)

---

## 🏢 What is Casa Milan Atelier?

Casa Milan Atelier is an **enterprise-grade luxury e-commerce platform** designed for world-class brand experiences. It combines:

- ✨ **Luxury Brand Experience** — Premium UI/UX inspired by Net-a-Porter, SKIMS, and Aritzia
- 🛍️ **Full E-Commerce** — Products, collections, cart, checkout, orders, payments, shipping
- 💎 **Social Impact** — Every purchase donates to orphanage homes
- 🧠 **AI Assistant** — GPT-4 powered shopping assistant for personalized guidance
- 👥 **Loyalty & Referrals** — Points system, tiered memberships, referral rewards
- 🌍 **Multi-Currency** — GHS, USD, GBP, EUR, CAD with real-time conversion
- 📊 **Admin Dashboard** — Powerful operations center for managing all business aspects
- 📱 **Mobile Ready** — Fully responsive + future iOS/Android app compatibility
- 🚀 **Production Ready** — Deployed on Vercel with enterprise security, monitoring, and scalability

---

## 🎯 Core Features

### Customer Experience
- **Shopping** — Advanced search, filters, product recommendations
- **Wishlists** — Save, organize, share wishlists
- **Reviews** — Verified purchase reviews with photos/videos
- **Accounts** — Order history, loyalty points, referrals, addresses
- **Checkout** — Multi-step, guest checkout, multiple payment methods
- **AI Assistant** — Chat-based shopping help, styling recommendations
- **Notifications** — Order updates, back-in-stock alerts, loyalty rewards

### Social Impact
- **Donation Tracking** — Every purchase automatically donates 50 pesewas
- **Impact Hub** — Transparency dashboard showing total donations and children helped
- **Annual Reports** — Published impact reports with stories and metrics
- **Partner Organizations** — Showcase of partner orphanages

### Admin Dashboard
- **Products** — Unlimited products with variants, images, videos, SEO
- **Collections** — Organize products into collections with scheduling
- **Orders** — Manage orders, track shipping, process refunds
- **Customers** — Customer profiles, loyalty status, support history
- **Marketing** — Campaigns, discount codes, email marketing
- **Donations** — Track all donations with full transparency
- **Analytics** — Revenue, traffic, products, customers, conversion metrics
- **CMS** — Edit pages, blog posts, FAQ without coding
- **Settings** — Store configuration, delivery zones, currencies, payment methods

### Technical Features
- **Payments** — Paystack, Mobile Money, Bank Transfer, Card payments
- **Shipping** — DHL integration, domestic delivery zones, tracking
- **Search** — AI-enhanced search with Algolia/Meilisearch
- **Email** — Transactional and marketing emails via Resend
- **Storage** — Image/video hosting and optimization via Cloudinary
- **Analytics** — Google Analytics, Vercel Analytics, conversion tracking
- **Authentication** — Clerk with role-based access control
- **Database** — PostgreSQL with Prisma ORM for type-safe queries
- **Monitoring** — Sentry error tracking, performance monitoring

---

## 📁 Project Structure

```
casa-milan-atelier/
├── apps/
│   └── web/                    # Next.js web application
│       ├── src/
│       │   ├── app/            # Next.js App Router + API routes
│       │   ├── components/     # React components
│       │   ├── lib/            # Utilities and helpers
│       │   ├── hooks/          # Custom React hooks
│       │   ├── types/          # TypeScript types
│       │   └── styles/         # Global styles
│       ├── public/             # Static assets
│       └── package.json
├── packages/
│   ├── database/               # Prisma schema and migrations
│   ├── ui/                     # Shared UI components
│   ├── utils/                  # Shared utilities
│   └── types/                  # Shared TypeScript types
├── docs/                       # Documentation
├── .env.example               # Environment variables template
├── next.config.js             # Next.js configuration
├── tailwind.config.ts         # Tailwind CSS configuration
├── tsconfig.json              # TypeScript configuration
└── package.json               # Monorepo root configuration
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** 20.0.0+
- **PostgreSQL** 14+
- **pnpm** 9.0.0+

### Installation

```bash
# 1. Clone repository
git clone https://github.com/yourusername/casa-milan-atelier.git
cd casa-milan-atelier

# 2. Install dependencies
pnpm install

# 3. Set up environment
cp .env.example .env.local
# Edit .env.local with your configuration

# 4. Setup database
pnpm db:push
pnpm db:seed

# 5. Run development server
pnpm dev
```

Visit `http://localhost:3000`

For detailed setup instructions, see [SETUP_DEPLOYMENT_GUIDE.md](./SETUP_DEPLOYMENT_GUIDE.md)

---

## 🛠️ Technology Stack

### Frontend
- **Framework** — Next.js 14+ (App Router)
- **Language** — TypeScript
- **Styling** — Tailwind CSS + CSS-in-JS
- **Animation** — Framer Motion
- **Components** — ShadCN UI + custom components
- **Forms** — React Hook Form + Zod validation
- **State** — Zustand, React Query

### Backend
- **Runtime** — Node.js
- **API** — Next.js API Routes
- **ORM** — Prisma
- **Database** — PostgreSQL
- **Search** — Algolia or Meilisearch
- **Auth** — Clerk
- **Payments** — Paystack
- **Email** — Resend
- **Storage** — Cloudinary
- **AI** — OpenAI GPT-4
- **Analytics** — Google Analytics 4

### Deployment
- **Hosting** — Vercel (serverless)
- **Database** — Neon, Railway, or AWS RDS
- **Monitoring** — Sentry
- **CI/CD** — GitHub Actions
- **CDN** — Vercel Edge Network

---

## 📱 API

Casa Milan provides a comprehensive REST API for all operations:

**Authentication**
- `/api/auth/register` — User registration
- `/api/auth/login` — User login
- `/api/auth/logout` — Logout

**Products**
- `/api/products` — Get products with filters
- `/api/products/:id` — Get single product
- `/api/products/:id/reviews` — Get product reviews

**Orders**
- `/api/orders` — Create and list orders
- `/api/orders/:id` — Get order details
- `/api/orders/:id/cancel` — Cancel order

**Customers**
- `/api/customers/profile` — Get user profile
- `/api/customers/addresses` — Manage addresses
- `/api/customers/payment-methods` — Manage payment methods

**AI Assistant**
- `/api/ai-assistant/chat` — Chat with AI
- `/api/ai-assistant/history` — Conversation history

**Donations**
- `/api/donations/stats` — Get donation statistics
- `/api/donations/timeline` — Get donation timeline

See [API_DOCUMENTATION.md](./API_DOCUMENTATION.md) for complete endpoint documentation.

---

## 🎨 Design System

Casa Milan follows a luxury brand design system:

**Colors**
- Warm Ivory (#F8F5F0) — Primary background
- Soft Champagne (#E8DDCF) — Secondary
- Deep Teal (#0F6D73) — Accent
- Satin Gold (#C9A96E) — Luxury accent
- Charcoal (#2B2B2B) — Text

**Typography**
- Display — Canela, Bodoni Moda, Playfair Display
- Body — Inter, Manrope, Plus Jakarta Sans
- Buttons — Satoshi, Manrope

**Spacing**
- Generous whitespace (luxury feeling)
- 8px base unit system
- Minimal cluttering

**Animations**
- Purposeful, smooth transitions
- Fade, slide, scale effects
- No excessive animations

---

## 📊 Database Schema

The database includes:

- **Users & Auth** — User accounts, roles, permissions, login history
- **Products** — Products, variants, images, videos, reviews
- **Collections & Categories** — Organize products
- **Orders & Payments** — Order management with Paystack integration
- **Customers** — Customer profiles, addresses, loyalty accounts
- **Reviews** — Product reviews with ratings and media
- **Wishlist** — Save and organize favorite products
- **Loyalty** — Points, tiers, transactions
- **Referrals** — Referral tracking and rewards
- **Donations** — Donation records and impact tracking
- **Content** — Blog posts, pages, FAQ
- **Analytics** — Event tracking, user behavior

See [schema.prisma](./schema.prisma) for complete schema.

---

## 🔐 Security

Casa Milan implements enterprise-grade security:

- ✅ **HTTPS/TLS** — Enforced encryption
- ✅ **CSRF Protection** — Token-based protection
- ✅ **XSS Prevention** — Input validation and sanitization
- ✅ **SQL Injection Prevention** — Parameterized queries (Prisma)
- ✅ **Rate Limiting** — API endpoint rate limiting
- ✅ **Authentication** — Clerk with 2FA ready
- ✅ **Role-Based Access** — Admin dashboard permissions
- ✅ **Audit Logging** — Track all admin actions
- ✅ **Payment Security** — PCI compliance via Paystack
- ✅ **Data Encryption** — Sensitive data encryption at rest

---

## 📈 Performance

**Lighthouse Targets**
- Performance: 95+
- Accessibility: 100
- Best Practices: 100
- SEO: 100

**Core Web Vitals**
- FCP (First Contentful Paint): < 1.5s
- LCP (Largest Contentful Paint): < 2.5s
- CLS (Cumulative Layout Shift): < 0.1
- TTFB (Time to First Byte): < 600ms

**Optimizations**
- Image optimization with Cloudinary
- Code splitting and lazy loading
- Server-side rendering (Next.js SSR)
- Edge caching with Vercel
- Database query optimization
- API response caching
- CSS-in-JS optimization

---

## 📚 Documentation

- **[SETUP_DEPLOYMENT_GUIDE.md](./SETUP_DEPLOYMENT_GUIDE.md)** — Detailed setup and deployment instructions
- **[API_DOCUMENTATION.md](./API_DOCUMENTATION.md)** — Complete API reference with examples
- **[PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md)** — Folder structure explanation
- **[schema.prisma](./schema.prisma)** — Database schema
- **[.env.example](./.env.example)** — Environment variables guide

---

## 🚀 Deployment

### Deploy to Vercel (Recommended)

```bash
# 1. Push to GitHub
git push origin main

# 2. Connect to Vercel
# Visit https://vercel.com and connect your GitHub repo

# 3. Add environment variables in Vercel
# Set all variables from .env.example

# 4. Deploy
# Automatic deployment on git push
```

For detailed deployment instructions, see [SETUP_DEPLOYMENT_GUIDE.md](./SETUP_DEPLOYMENT_GUIDE.md)

---

## 🧪 Testing

```bash
# Run tests
pnpm test

# Type checking
pnpm type-check

# Linting
pnpm lint

# Format code
pnpm format
```

---

## 📞 Support

- **Email** — support@casamilan.com
- **GitHub Issues** — Report bugs and feature requests
- **Documentation** — See `/docs` directory
- **Status Page** — status.casamilan.com

---

## 📄 License

This project is proprietary and confidential. Unauthorized copying, distribution, or modification is prohibited.

---

## 🙏 Contributors

Casa Milan Atelier is built by a passionate team dedicated to luxury and purpose.

---

## 🎯 Roadmap

### Phase 1 (Current)
- ✅ Core e-commerce platform
- ✅ Payment integration
- ✅ Admin dashboard
- ✅ AI assistant

### Phase 2
- 📱 iOS app (shared backend)
- 📱 Android app (shared backend)
- 🌍 Multi-language support
- 💬 Live chat support

### Phase 3
- 🏪 Physical store integration
- 🏭 Wholesale platform
- 🎁 Subscription box service
- 🔄 Marketplace for designers

### Phase 4
- 🤖 Advanced AI personalization
- 👓 AR try-on feature
- 🎮 Gamification
- 📡 Real-time inventory sync

---

## 💡 Philosophy

**Luxury without Noise**

Casa Milan believes that luxury should feel effortless, not overwhelming. Every design decision prioritizes:

- **Elegance** — Minimalist, refined aesthetics
- **Purpose** — Every feature serves the customer
- **Transparency** — Clear communication and impact tracking
- **Quality** — Premium materials, craftsmanship, service
- **Sustainability** — Ethical practices and social responsibility

---

## 🔗 Links

- **Website** — https://casamilan.com
- **Instagram** — @casamilan
- **LinkedIn** — linkedin.com/company/casamilan
- **Donate** — casamilan.com/impact

---

**Made with ❤️ for luxury with purpose**

Casa Milan Atelier © 2025. All rights reserved.

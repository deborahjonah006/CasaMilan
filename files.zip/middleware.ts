// src/middleware.ts
import { authMiddleware } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Clerk authentication middleware
 */
export default authMiddleware({
  // Public routes that don't need authentication
  publicRoutes: [
    "/",
    "/collections/(.*)",
    "/products/(.*)",
    "/impact",
    "/about",
    "/contact",
    "/faq",
    "/blog(.*)",
    "/api/products",
    "/api/collections",
    "/api/search",
    "/api/webhooks/(.*)",
    "/sign-in",
    "/sign-up",
  ],

  // Routes that always require authentication
  ignoredRoutes: [
    "/api/webhooks/paystack",
    "/api/webhooks/clerk",
    "/_next",
    "/public",
  ],
});

/**
 * Custom middleware for API routes
 */
export async function apiMiddleware(req: NextRequest) {
  // Add request ID for tracing
  const requestId = crypto.randomUUID();
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-request-id", requestId);

  // Rate limiting check
  const ip = req.headers.get("x-forwarded-for") || "unknown";
  const rateLimit = await checkRateLimit(ip);

  if (!rateLimit.allowed) {
    return NextResponse.json(
      {
        success: false,
        error: "Rate limit exceeded",
      },
      {
        status: 429,
        headers: {
          "X-RateLimit-Limit": String(rateLimit.limit),
          "X-RateLimit-Remaining": "0",
          "X-RateLimit-Reset": String(rateLimit.resetTime),
        },
      }
    );
  }

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
    status: 200,
    headers: {
      "X-Request-ID": requestId,
      "X-RateLimit-Limit": String(rateLimit.limit),
      "X-RateLimit-Remaining": String(rateLimit.remaining),
      "X-RateLimit-Reset": String(rateLimit.resetTime),
    },
  });
}

/**
 * Rate limiting check (simplified - use Redis in production)
 */
async function checkRateLimit(
  ip: string
): Promise<{
  allowed: boolean;
  limit: number;
  remaining: number;
  resetTime: number;
}> {
  // Simplified rate limiter
  // In production, use Redis or a dedicated service
  const limit = 100; // requests per minute
  const windowMs = 60 * 1000; // 1 minute

  // Store in memory (replace with Redis for production)
  const key = `rate-limit:${ip}`;
  const now = Date.now();

  // This is a simplified version
  // In production, use: redis.incr(key) + redis.expire(key, windowMs)

  return {
    allowed: true,
    limit,
    remaining: limit - 1,
    resetTime: now + windowMs,
  };
}

/**
 * CORS middleware
 */
export function corsMiddleware(req: NextRequest) {
  const allowedOrigins = [
    "http://localhost:3000",
    "https://casamilan.com",
    "https://www.casamilan.com",
  ];

  const origin = req.headers.get("origin");
  const isAllowed = allowedOrigins.includes(origin || "");

  if (req.method === "OPTIONS") {
    return new NextResponse(null, {
      status: 200,
      headers: {
        "Access-Control-Allow-Origin": isAllowed ? origin || "*" : "",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400",
      },
    });
  }

  return NextResponse.next({
    request: {
      headers: new Headers(req.headers),
    },
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": isAllowed ? origin || "*" : "",
    },
  });
}

/**
 * Security headers middleware
 */
export function securityHeadersMiddleware(req: NextRequest) {
  const requestHeaders = new Headers(req.headers);

  // Add security headers
  requestHeaders.set("X-Content-Type-Options", "nosniff");
  requestHeaders.set("X-Frame-Options", "SAMEORIGIN");
  requestHeaders.set("X-XSS-Protection", "1; mode=block");
  requestHeaders.set(
    "Strict-Transport-Security",
    "max-age=31536000; includeSubDomains"
  );
  requestHeaders.set(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline';"
  );
  requestHeaders.set("Referrer-Policy", "strict-origin-when-cross-origin");
  requestHeaders.set(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=(self)"
  );

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

/**
 * Validate API key for external integrations
 */
export async function validateApiKey(req: NextRequest): Promise<boolean> {
  const apiKey = req.headers.get("x-api-key");

  if (!apiKey) {
    return false;
  }

  // Validate against stored API keys
  // In production, hash and store in database
  const validKeys = [process.env.EXTERNAL_API_KEY];

  return validKeys.includes(apiKey);
}

/**
 * Validate request signature (for webhooks)
 */
export function validateWebhookSignature(
  req: NextRequest,
  secret: string
): boolean {
  const signature = req.headers.get("x-webhook-signature");

  if (!signature) {
    return false;
  }

  // Validate HMAC signature
  // Implementation depends on webhook provider
  return true;
}

/**
 * Log request (for monitoring)
 */
export function logRequest(
  req: NextRequest,
  response: NextResponse,
  duration: number
) {
  const log = {
    timestamp: new Date().toISOString(),
    method: req.method,
    path: req.nextUrl.pathname,
    status: response.status,
    duration: `${duration}ms`,
    ip: req.headers.get("x-forwarded-for") || "unknown",
  };

  // Log to console in development
  if (process.env.NODE_ENV === "development") {
    console.log(JSON.stringify(log));
  }

  // In production, send to monitoring service (Sentry, etc.)
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    "/((?!_next/static|_next/image|favicon.ico|public).*)",
  ],
};

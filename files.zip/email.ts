// src/lib/email.ts
import { Resend } from "resend";
import { Order, User } from "@prisma/client";

const resend = new Resend(process.env.RESEND_API_KEY);

const SENDER_EMAIL = process.env.NEXT_PUBLIC_SENDER_EMAIL || "noreply@casamilan.com";
const SUPPORT_EMAIL = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || "support@casamilan.com";

/**
 * Send order confirmation email
 */
export async function sendOrderConfirmationEmail(order: Order & { items?: any[] }) {
  try {
    const itemsHtml = order.items
      ?.map(
        (item) => `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #e8ddcf;">
          ${item.product?.name || "Product"}
        </td>
        <td style="padding: 12px; text-align: center; border-bottom: 1px solid #e8ddcf;">
          ${item.quantity}
        </td>
        <td style="padding: 12px; text-align: right; border-bottom: 1px solid #e8ddcf;">
          GH₵ ${item.price?.toFixed(2) || "0.00"}
        </td>
      </tr>
    `
      )
      .join("");

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body { font-family: Inter, sans-serif; color: #2B2B2B; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #F8F5F0; padding: 20px; text-align: center; }
            .header h1 { margin: 0; color: #0F6D73; font-size: 24px; }
            .content { padding: 20px 0; }
            .order-summary { background-color: #F8F5F0; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .order-number { color: #0F6D73; font-weight: 600; }
            table { width: 100%; border-collapse: collapse; }
            .total-row { font-weight: 600; font-size: 18px; }
            .button { 
              display: inline-block;
              background-color: #0F6D73;
              color: white;
              padding: 12px 24px;
              text-decoration: none;
              border-radius: 4px;
              margin: 20px 0;
            }
            .footer { 
              border-top: 1px solid #e8ddcf;
              padding-top: 20px;
              text-align: center;
              font-size: 12px;
              color: #999;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Casa Milan Atelier</h1>
              <p>Luxury with Purpose</p>
            </div>

            <div class="content">
              <h2>Thank You for Your Order</h2>
              <p>Dear ${order.customerEmail},</p>
              
              <p>Your order has been confirmed and will be processed shortly.</p>

              <div class="order-summary">
                <p><strong>Order Number:</strong> <span class="order-number">${order.orderNumber}</span></p>
                <p><strong>Order Date:</strong> ${new Date(order.createdAt).toLocaleDateString()}</p>
                <p><strong>Status:</strong> ${order.status}</p>
              </div>

              <h3>Order Details</h3>
              <table>
                <thead>
                  <tr style="background-color: #e8ddcf;">
                    <th style="text-align: left; padding: 12px;">Product</th>
                    <th style="text-align: center; padding: 12px;">Quantity</th>
                    <th style="text-align: right; padding: 12px;">Price</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsHtml}
                </tbody>
              </table>

              <div style="margin-top: 20px; text-align: right;">
                <table style="width: auto; margin-left: auto;">
                  <tr>
                    <td style="padding: 8px 12px;">Subtotal:</td>
                    <td style="padding: 8px 12px; text-align: right;">GH₵ ${order.subtotal.toFixed(2)}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 12px;">Tax:</td>
                    <td style="padding: 8px 12px; text-align: right;">GH₵ ${order.taxAmount.toFixed(2)}</td>
                  </tr>
                  <tr>
                    <td style="padding: 8px 12px;">Shipping:</td>
                    <td style="padding: 8px 12px; text-align: right;">GH₵ ${order.shippingCost.toFixed(2)}</td>
                  </tr>
                  <tr class="total-row">
                    <td style="padding: 12px 12px; border-top: 2px solid #0F6D73;">Total:</td>
                    <td style="padding: 12px 12px; text-align: right; border-top: 2px solid #0F6D73;">GH₵ ${order.total.toFixed(2)}</td>
                  </tr>
                </table>
              </div>

              <a href="https://casamilan.com/orders/${order.id}" class="button">
                Track Your Order
              </a>

              <h3>About Your Donation</h3>
              <p>Every purchase contributes to our social impact initiative. Your order donation will help us support orphanage homes in Ghana.</p>
              <p><a href="https://casamilan.com/impact" style="color: #0F6D73;">View Our Impact</a></p>
            </div>

            <div class="footer">
              <p>Casa Milan Atelier<br>Luxury with Purpose</p>
              <p>Questions? <a href="mailto:${SUPPORT_EMAIL}">${SUPPORT_EMAIL}</a></p>
              <p>&copy; 2025 Casa Milan Atelier. All rights reserved.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    const result = await resend.emails.send({
      from: SENDER_EMAIL,
      to: order.customerEmail,
      subject: `Order Confirmation - ${order.orderNumber}`,
      html,
    });

    if (result.error) {
      console.error("Resend error:", result.error);
      return false;
    }

    return true;
  } catch (error) {
    console.error("Error sending order confirmation:", error);
    return false;
  }
}

/**
 * Send shipment notification
 */
export async function sendShipmentNotification(
  email: string,
  orderNumber: string,
  trackingNumber?: string,
  trackingUrl?: string
) {
  try {
    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body { font-family: Inter, sans-serif; color: #2B2B2B; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .alert { background-color: #ecfdf5; padding: 16px; border-left: 4px solid #10b981; border-radius: 4px; }
            .tracking { background-color: #f8f5f0; padding: 16px; border-radius: 4px; margin: 20px 0; font-family: monospace; }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Your Order Has Shipped!</h1>
            
            <div class="alert">
              <p><strong>Your order ${orderNumber} is on its way!</strong></p>
            </div>

            <p>We're excited to let you know that your order has been dispatched and is in transit.</p>

            ${trackingNumber ? `
              <h3>Tracking Information</h3>
              <div class="tracking">${trackingNumber}</div>
              ${trackingUrl ? `<p><a href="${trackingUrl}">Track Your Package</a></p>` : ""}
            ` : ""}

            <p>You'll receive your order within 3-5 business days. Thank you for your patience!</p>

            <p>Questions? Contact us at ${SUPPORT_EMAIL}</p>
          </div>
        </body>
      </html>
    `;

    const result = await resend.emails.send({
      from: SENDER_EMAIL,
      to: email,
      subject: `Shipment Update - ${orderNumber}`,
      html,
    });

    return !result.error;
  } catch (error) {
    console.error("Error sending shipment notification:", error);
    return false;
  }
}

/**
 * Send password reset email
 */
export async function sendPasswordResetEmail(email: string, resetLink: string) {
  try {
    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body { font-family: Inter, sans-serif; color: #2B2B2B; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .button { 
              display: inline-block;
              background-color: #0F6D73;
              color: white;
              padding: 12px 24px;
              text-decoration: none;
              border-radius: 4px;
            }
            .warning { color: #dc2626; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Reset Your Password</h1>
            
            <p>We received a request to reset your password. Click the button below to create a new password.</p>
            
            <a href="${resetLink}" class="button">Reset Password</a>
            
            <p>This link will expire in 24 hours.</p>
            
            <p class="warning">If you didn't request a password reset, please ignore this email or contact ${SUPPORT_EMAIL}</p>
          </div>
        </body>
      </html>
    `;

    const result = await resend.emails.send({
      from: SENDER_EMAIL,
      to: email,
      subject: "Reset Your Casa Milan Password",
      html,
    });

    return !result.error;
  } catch (error) {
    console.error("Error sending password reset:", error);
    return false;
  }
}

/**
 * Send loyalty reward email
 */
export async function sendLoyaltyRewardEmail(
  email: string,
  pointsEarned: number,
  currentPoints: number
) {
  try {
    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body { font-family: Inter, sans-serif; color: #2B2B2B; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .reward-box { 
              background-color: #f9f0e1;
              padding: 20px;
              border-radius: 8px;
              text-align: center;
              margin: 20px 0;
            }
            .points { font-size: 32px; color: #c9a96e; font-weight: 600; }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>You Earned Loyalty Points!</h1>
            
            <div class="reward-box">
              <p>You've earned</p>
              <div class="points">+${pointsEarned} points</div>
              <p>Your total balance: ${currentPoints} points</p>
            </div>

            <p>Keep shopping to earn more points and unlock exclusive rewards!</p>
            
            <p><a href="https://casamilan.com/loyalty">View Your Rewards</a></p>
          </div>
        </body>
      </html>
    `;

    const result = await resend.emails.send({
      from: SENDER_EMAIL,
      to: email,
      subject: `You Earned ${pointsEarned} Loyalty Points!`,
      html,
    });

    return !result.error;
  } catch (error) {
    console.error("Error sending loyalty reward:", error);
    return false;
  }
}

/**
 * Send referral bonus email
 */
export async function sendReferralBonusEmail(
  email: string,
  referralReward: any
) {
  try {
    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body { font-family: Inter, sans-serif; color: #2B2B2B; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .bonus-box { 
              background-color: #ecfdf5;
              padding: 20px;
              border-radius: 8px;
              border-left: 4px solid #10b981;
              margin: 20px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Your Referral Paid Off!</h1>
            
            <div class="bonus-box">
              <p>Your friend just made a purchase!</p>
              <p><strong>You've been rewarded with:</strong></p>
              <p style="font-size: 18px; color: #10b981;">
                ${referralReward.type === "DISCOUNT_CODE" ? "Discount Code" : 
                  referralReward.type === "CREDIT" ? "GH₵ " + referralReward.value : 
                  referralReward.value + " Points"}
              </p>
            </div>

            <p>Keep sharing your referral link to earn more rewards!</p>
            
            <p><a href="https://casamilan.com/referral">Share & Earn</a></p>
          </div>
        </body>
      </html>
    `;

    const result = await resend.emails.send({
      from: SENDER_EMAIL,
      to: email,
      subject: "Congratulations! You Earned a Referral Reward",
      html,
    });

    return !result.error;
  } catch (error) {
    console.error("Error sending referral bonus:", error);
    return false;
  }
}

/**
 * Send newsletter
 */
export async function sendNewsletter(
  emails: string[],
  subject: string,
  html: string
) {
  try {
    const result = await resend.emails.send({
      from: SENDER_EMAIL,
      to: emails,
      subject,
      html,
    });

    return !result.error;
  } catch (error) {
    console.error("Error sending newsletter:", error);
    return false;
  }
}

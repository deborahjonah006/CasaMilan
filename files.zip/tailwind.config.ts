// tailwind.config.ts
import type { Config } from "tailwindcss";
import defaultTheme from "tailwindcss/defaultTheme";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      // Color palette from brand guidelines
      colors: {
        // Primary backgrounds
        ivory: {
          50: "#FDFBF8",
          100: "#F8F5F0",
          200: "#F0E8E0",
          300: "#E8DCC8",
          400: "#E0D0B0",
          500: "#D8C498",
          600: "#D0B880",
          700: "#C8AC68",
          800: "#C0A050",
          900: "#B89438",
        },

        // Secondary - Soft Champagne
        champagne: {
          50: "#FEFBF7",
          100: "#E8DDCF",
          200: "#E0D5C7",
          300: "#D8CDBF",
          400: "#D0C5B7",
          500: "#C8BDAF",
          600: "#C0B5A7",
          700: "#B8AD9F",
          800: "#B0A597",
          900: "#A89D8F",
        },

        // Accent - Deep Teal
        teal: {
          50: "#F0F8F9",
          100: "#E1F2F4",
          200: "#C3E5E9",
          300: "#A5D8DE",
          400: "#87CBD3",
          500: "#69BEC8",
          600: "#4BB1BD",
          700: "#2DA4B2",
          800: "#0F6D73",
          900: "#0A4A50",
        },

        // Luxury - Satin Gold
        gold: {
          50: "#FEF9F3",
          100: "#F9F0E1",
          200: "#F0E1C3",
          300: "#E8D2A5",
          400: "#E0C387",
          500: "#D8B469",
          600: "#D0A54B",
          700: "#C9A96E",
          800: "#B59145",
          900: "#8B7535",
        },

        // Dark Accent - Rich Espresso
        espresso: {
          50: "#F5F3F1",
          100: "#E8E3DF",
          200: "#D4CCC4",
          300: "#B9AFA5",
          400: "#8B7F78",
          500: "#5D574F",
          600: "#4A4440",
          700: "#3A2C2A",
          800: "#2A2420",
          900: "#1A1A18",
        },

        // Neutral - Taupe
        taupe: {
          50: "#F8F7F5",
          100: "#E8E5E0",
          200: "#D9D3CA",
          300: "#CAC1B4",
          400: "#B9AFA5",
          500: "#B7A89A",
          600: "#A89891",
          700: "#998A83",
          800: "#8A7C74",
          900: "#7B6E66",
        },

        // Text - Charcoal
        charcoal: {
          50: "#F5F5F5",
          100: "#EBEBEB",
          200: "#D7D7D7",
          300: "#C3C3C3",
          400: "#AFAFAF",
          500: "#9B9B9B",
          600: "#878787",
          700: "#3A3A3A",
          800: "#2B2B2B",
          900: "#1A1A1A",
        },

        // Status colors
        success: "#10B981",
        error: "#DC2626",
        warning: "#F59E0B",
        info: "#3B82F6",
      },

      // Typography
      fontFamily: {
        // Display - Elegant serif for headings
        display: [
          "Canela",
          "Editorial New",
          "Bodoni Moda",
          "Cormorant Garamond",
          "Playfair Display",
          ...defaultTheme.fontFamily.serif,
        ],
        // Body - Clean sans-serif
        sans: [
          "Inter",
          "Manrope",
          "Plus Jakarta Sans",
          "General Sans",
          ...defaultTheme.fontFamily.sans,
        ],
        // Button - Special button face
        button: ["Satoshi", "Manrope", ...defaultTheme.fontFamily.sans],
      },

      fontSize: {
        // Display sizes
        "display-lg": ["64px", { lineHeight: "72px", fontWeight: "500" }],
        "display-md": ["48px", { lineHeight: "56px", fontWeight: "500" }],
        "display-sm": ["36px", { lineHeight: "44px", fontWeight: "500" }],

        // Heading sizes
        "heading-lg": ["28px", { lineHeight: "36px", fontWeight: "600" }],
        "heading-md": ["24px", { lineHeight: "32px", fontWeight: "600" }],
        "heading-sm": ["20px", { lineHeight: "28px", fontWeight: "600" }],

        // Body sizes
        "body-lg": ["18px", { lineHeight: "28px", fontWeight: "400" }],
        "body-md": ["16px", { lineHeight: "24px", fontWeight: "400" }],
        "body-sm": ["14px", { lineHeight: "20px", fontWeight: "400" }],

        // Caption
        "caption": ["12px", { lineHeight: "16px", fontWeight: "400" }],
      },

      // Spacing - Luxurious whitespace
      spacing: {
        "4xs": "2px",
        "3xs": "4px",
        "2xs": "8px",
        "xs": "12px",
        "sm": "16px",
        "md": "24px",
        "lg": "32px",
        "xl": "48px",
        "2xl": "64px",
        "3xl": "80px",
        "4xl": "96px",
        "5xl": "120px",
      },

      // Border radius - Subtle, minimal
      borderRadius: {
        none: "0",
        sm: "2px",
        md: "4px",
        lg: "8px",
        xl: "12px",
        "2xl": "16px",
        full: "9999px",
      },

      // Box shadow - Elegant, minimal
      boxShadow: {
        none: "none",
        sm: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
        md: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
        lg: "0 10px 15px -3px rgba(0, 0, 0, 0.1)",
        xl: "0 20px 25px -5px rgba(0, 0, 0, 0.1)",
        "2xl": "0 25px 50px -12px rgba(0, 0, 0, 0.15)",
        // Luxury shadows
        luxury: "0 10px 40px rgba(0, 0, 0, 0.08)",
        "luxury-lg": "0 20px 60px rgba(0, 0, 0, 0.12)",
      },

      // Animation and transitions
      animation: {
        // Smooth, purposeful animations
        fade: "fade 0.3s ease-in-out",
        "slide-up": "slideUp 0.5s ease-out",
        "slide-down": "slideDown 0.5s ease-out",
        "scale-in": "scaleIn 0.3s ease-out",
        "fade-in-up": "fadeInUp 0.6s ease-out",
      },

      keyframes: {
        fade: {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        slideUp: {
          from: {
            opacity: "0",
            transform: "translateY(20px)",
          },
          to: {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
        slideDown: {
          from: {
            opacity: "0",
            transform: "translateY(-20px)",
          },
          to: {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
        scaleIn: {
          from: {
            opacity: "0",
            transform: "scale(0.95)",
          },
          to: {
            opacity: "1",
            transform: "scale(1)",
          },
        },
        fadeInUp: {
          from: {
            opacity: "0",
            transform: "translateY(30px)",
          },
          to: {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
      },

      transitionDuration: {
        "0": "0ms",
        "75": "75ms",
        "100": "100ms",
        "150": "150ms",
        "200": "200ms",
        "300": "300ms",
        "500": "500ms",
        "700": "700ms",
        "1000": "1000ms",
      },

      // Backdrop blur for modals
      backdropBlur: {
        none: "0",
        sm: "4px",
        md: "12px",
        lg: "16px",
      },

      // Opacity scale
      opacity: {
        "0": "0",
        "5": "0.05",
        "10": "0.1",
        "20": "0.2",
        "30": "0.3",
        "40": "0.4",
        "50": "0.5",
        "60": "0.6",
        "70": "0.7",
        "80": "0.8",
        "90": "0.9",
        "100": "1",
      },

      // Width and height
      width: {
        screen: "100vw",
        "screen-safe": "100vw",
      },

      height: {
        screen: "100vh",
        "screen-safe": "100dvh",
      },

      // Min/Max content
      minHeight: {
        screen: "100vh",
      },

      // Z-index - Layering
      zIndex: {
        auto: "auto",
        "0": "0",
        "10": "10",
        "20": "20",
        "30": "30",
        "40": "40",
        "50": "50",
        "dropdown": "1000",
        "sticky": "1020",
        "fixed": "1030",
        "modal": "1040",
        "popover": "1050",
        "tooltip": "1060",
      },
    },
  },

  plugins: [
    // Form styling
    require("@tailwindcss/forms")({
      strategy: "class",
    }),
    // Typography plugin for rich content
    require("@tailwindcss/typography"),
    // Custom plugins can be added here
    ({ addBase, theme }) => {
      addBase({
        // Smooth scrolling
        html: {
          scrollBehavior: "smooth",
        },
        // Base typography
        body: {
          "@apply font-sans text-charcoal-800": {},
        },
        // Selection color
        "::selection": {
          "@apply bg-gold-200 text-charcoal-900": {},
        },
      });
    },
  ],
};

export default config;

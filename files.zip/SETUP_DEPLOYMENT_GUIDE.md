# Casa Milan Atelier - Setup & Deployment Guide

## Table of Contents
1. [Initial Setup](#initial-setup)
2. [Local Development](#local-development)
3. [Database Configuration](#database-configuration)
4. [Integration Setup](#integration-setup)
5. [Running the Application](#running-the-application)
6. [Production Deployment](#production-deployment)
7. [Monitoring & Maintenance](#monitoring--maintenance)

---

## Initial Setup

### Prerequisites
- Node.js 20.0.0+ ([Download](https://nodejs.org))
- PostgreSQL 14+ ([Download](https://www.postgresql.org))
- pnpm 9.0.0+ (`npm install -g pnpm`)
- Git
- GitHub account (for CI/CD)

### Step 1: Clone & Install Dependencies

```bash
# Clone the repository
git clone https://github.com/yourusername/casa-milan-atelier.git
cd casa-milan-atelier

# Install dependencies
pnpm install

# Generate Prisma client
pnpm db:generate
```

### Step 2: Environment Configuration

```bash
# Copy example environment file
cp .env.example .env.local

# Edit with your values
nano .env.local
```

**Essential variables to set:**
```
DATABASE_URL=postgresql://user:password@localhost:5432/casa_milan
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY=pk_live_7373b4ad63179750ef4607b17b34d8040bca897b
PAYSTACK_SECRET_KEY=sk_live_04157df796a73422b6a70d9300212687da0ff436
OPENAI_API_KEY=sk_...
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
```

---

## Database Configuration

### Step 1: Create PostgreSQL Database

```bash
# macOS / Linux
createdb casa_milan

# Windows (using psql)
psql -U postgres -c "CREATE DATABASE casa_milan;"
```

### Step 2: Set Database URL

Update `.env.local`:
```
DATABASE_URL="postgresql://user:password@localhost:5432/casa_milan"
DIRECT_URL="postgresql://user:password@localhost:5432/casa_milan"
```

### Step 3: Initialize Database Schema

```bash
# Push Prisma schema to database
pnpm db:push

# Generate Prisma client
pnpm db:generate

# Seed initial data
pnpm db:seed
```

### Step 4: Access Database Studio (Optional)

```bash
# Open Prisma Studio for data visualization
pnpm db:studio

# Visit http://localhost:5555
```

---

## Integration Setup

### Clerk Authentication Setup

1. Go to https://dashboard.clerk.com
2. Create a new application
3. Copy API keys to `.env.local`:
   ```
   NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
   CLERK_SECRET_KEY=sk_test_...
   ```
4. Set up Allowed Origins in Clerk Dashboard:
   - Development: `http://localhost:3000`
   - Production: `https://yourdomain.com`

### Paystack Integration (Already Configured)

Your live keys are already configured:
- Public Key: `pk_live_7373b4ad63179750ef4607b17b34d8040bca897b`
- Secret Key: `sk_live_04157df796a73422b6a70d9300212687da0ff436`

**Important:** 
1. Set webhook in Paystack Dashboard:
   - Go to https://dashboard.paystack.com/settings/developer
   - Add webhook URL: `https://yourdomain.com/api/webhooks/paystack`
   - Copy webhook secret to `PAYSTACK_WEBHOOK_SECRET`

2. Test payments in staging first with test keys from Paystack Dashboard

### Cloudinary Setup

1. Go to https://cloudinary.com and sign up
2. Copy API credentials:
   ```
   NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=your_cloud_name
   CLOUDINARY_API_KEY=...
   CLOUDINARY_API_SECRET=...
   ```
3. Create upload preset for products:
   - In Cloudinary Dashboard → Settings → Upload
   - Create preset: `casa_milan_products`
   - Make it unsigned for client-side uploads

### OpenAI Setup

1. Go to https://platform.openai.com/api-keys
2. Create new API key
3. Add to `.env.local`:
   ```
   OPENAI_API_KEY=sk_...
   OPENAI_MODEL=gpt-4
   ```

### Resend Email Setup

1. Go to https://resend.com
2. Create account and verify domain
3. Add API key:
   ```
   RESEND_API_KEY=re_...
   NEXT_PUBLIC_SENDER_EMAIL=noreply@casamilan.com
   ```

### Google Analytics Setup

1. Go to https://analytics.google.com
2. Create new property for your website
3. Copy tracking ID:
   ```
   NEXT_PUBLIC_GOOGLE_ANALYTICS_ID=G-...
   ```

### Sentry Error Tracking (Optional)

1. Go to https://sentry.io
2. Create new project
3. Add credentials:
   ```
   NEXT_PUBLIC_SENTRY_AUTH_TOKEN=...
   SENTRY_ORG=...
   SENTRY_PROJECT=...
   ```

---

## Running the Application

### Development Mode

```bash
# Start development server
pnpm dev

# Application runs at http://localhost:3000
```

**Available URLs:**
- Frontend: http://localhost:3000
- Admin: http://localhost:3000/admin
- API: http://localhost:3000/api
- Prisma Studio: http://localhost:5555

### Build & Test Production

```bash
# Build for production
pnpm build

# Start production server
pnpm start

# Run tests
pnpm test

# Check types
pnpm type-check

# Format code
pnpm format
```

---

## Production Deployment

### Deploy to Vercel (Recommended)

#### Step 1: Push to GitHub

```bash
git add .
git commit -m "Initial commit: Casa Milan Atelier"
git push origin main
```

#### Step 2: Connect to Vercel

1. Go to https://vercel.com
2. Click "New Project"
3. Select your GitHub repository
4. Configure:
   - Framework: Next.js
   - Root Directory: `apps/web`
   - Build Command: `pnpm build`
   - Output Directory: `.next`

#### Step 3: Add Environment Variables

In Vercel Dashboard → Settings → Environment Variables:

```
DATABASE_URL = postgresql://...
DIRECT_URL = postgresql://...
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY = pk_live_...
CLERK_SECRET_KEY = sk_live_...
NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY = pk_live_7373b4ad63179750ef4607b17b34d8040bca897b
PAYSTACK_SECRET_KEY = sk_live_04157df796a73422b6a70d9300212687da0ff436
OPENAI_API_KEY = sk_...
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME = ...
CLOUDINARY_API_KEY = ...
CLOUDINARY_API_SECRET = ...
RESEND_API_KEY = re_...
NEXTAUTH_SECRET = [Generate: openssl rand -base64 32]
NEXT_PUBLIC_APP_URL = https://casamilan.com
```

#### Step 4: Deploy

```bash
# Automatic deployment on git push
# Or manually deploy from Vercel Dashboard
```

### Database Hosting

#### Option A: Neon (PostgreSQL as a Service)

1. Go to https://neon.tech
2. Create new project
3. Copy connection string:
   ```
   DATABASE_URL = postgresql://user:password@host/dbname
   ```
4. Set in Vercel environment variables

#### Option B: Railway

1. Go to https://railway.app
2. Create new PostgreSQL database
3. Copy connection string to Vercel

#### Option C: AWS RDS

1. Launch RDS PostgreSQL instance
2. Configure security groups
3. Add connection string to Vercel

### SSL/HTTPS Setup

- Vercel provides free SSL automatically
- Custom domain: Add in Vercel → Domains
- DNS records configured automatically

### Domain Setup

#### Vercel + Custom Domain

1. Buy domain from provider (Namecheap, GoDaddy, etc.)
2. In Vercel → Project Settings → Domains
3. Add your domain
4. Update DNS records as shown in Vercel

#### Update Clerk

1. https://dashboard.clerk.com → Settings
2. Add allowed origins:
   - Production: `https://casamilan.com`
   - Add www variant: `https://www.casamilan.com`

#### Update Paystack

1. https://dashboard.paystack.com → Settings
2. Add allowed URLs for webhooks

---

## Post-Deployment Checklist

- [ ] Test payment flow with Paystack test transaction
- [ ] Verify emails sending with Resend
- [ ] Check analytics tracking (Google Analytics)
- [ ] Test AI assistant responses
- [ ] Verify database backups are configured
- [ ] Enable Sentry error tracking
- [ ] Set up monitoring alerts
- [ ] Test email notifications
- [ ] Verify image optimization with Cloudinary
- [ ] Test mobile responsiveness
- [ ] Check Core Web Vitals in Google PageSpeed Insights
- [ ] Verify SEO with Google Search Console
- [ ] Set up monitoring dashboard

---

## Monitoring & Maintenance

### Health Checks

```bash
# Check application health
curl https://casamilan.com/api/health

# View error logs
# Sentry Dashboard: https://sentry.io/projects/

# View performance metrics
# Vercel Analytics: https://vercel.com/dashboard
```

### Database Backups

#### Automated Backups

- **Neon:** Automatic daily backups (included)
- **Railway:** Automatic backups (included)
- **AWS RDS:** Configure snapshot schedule

#### Manual Backup

```bash
# Export database
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql

# Import backup
psql $DATABASE_URL < backup_20240101.sql
```

### Regular Maintenance Tasks

**Daily:**
- Monitor error logs (Sentry)
- Check payment transactions
- Review customer support tickets

**Weekly:**
- Review analytics
- Check inventory levels
- Verify all integrations

**Monthly:**
- Update dependencies: `pnpm update`
- Review security advisories
- Analyze customer feedback
- Plan new features

### Scaling Considerations

**When traffic increases:**

1. **Database:**
   - Upgrade to higher tier (Neon, Railway)
   - Enable read replicas
   - Optimize slow queries

2. **API:**
   - Enable edge caching
   - Use serverless functions
   - Implement rate limiting

3. **Storage:**
   - Cloudinary: Upgrade plan
   - CDN: Enable edge caching

4. **Search:**
   - Algolia/Meilisearch: Upgrade plan
   - Add more indices

---

## Troubleshooting

### Build Errors

```bash
# Clear cache and rebuild
pnpm clean
pnpm install
pnpm build
```

### Database Connection Issues

```bash
# Test connection
psql $DATABASE_URL -c "SELECT 1"

# Check if database exists
psql -l

# Reset database (DANGER - deletes all data)
pnpm db:reset
```

### Payment Not Processing

1. Check Paystack dashboard for failed transactions
2. Verify webhook is configured correctly
3. Check logs in Vercel
4. Ensure test/live keys match environment

### Emails Not Sending

1. Verify Resend API key in `.env.local`
2. Check Resend dashboard for bounces
3. Verify sender email is verified
4. Check email logs in Vercel

### Images Not Loading

1. Verify Cloudinary credentials
2. Check file upload in Media Library
3. Ensure upload preset exists
4. Review Cloudinary usage quota

---

## Security Best Practices

1. **Secrets Management:**
   - Never commit `.env.local`
   - Use Vercel Secrets for sensitive values
   - Rotate API keys monthly

2. **Database Security:**
   - Use strong password for PostgreSQL
   - Enable SSL connections
   - Restrict IP access in firewall

3. **API Security:**
   - Enable rate limiting
   - Use CORS properly
   - Validate all inputs
   - Use HTTPS only

4. **Payment Security:**
   - Never log sensitive payment data
   - Use Paystack's secure methods
   - Enable 2FA on payment dashboard
   - Monitor for fraud

5. **Access Control:**
   - Enable 2FA for all admin accounts
   - Use role-based permissions
   - Audit all admin actions
   - Regular security audits

---

## Support & Resources

- **Documentation:** /docs/
- **API Reference:** /docs/API.md
- **Database Schema:** /docs/DATABASE.md
- **Architecture:** /docs/ARCHITECTURE.md
- **Issues:** GitHub Issues
- **Email:** support@casamilan.com

---

## Version Control & CI/CD

### GitHub Actions

Automated workflows in `.github/workflows/`:

```yaml
# deploy.yml - Deploys on push to main
# test.yml - Runs tests on all PRs
# security.yml - Checks for vulnerabilities
```

### Branch Strategy

```
main (production)
  ↓
staging (staging deployment)
  ↓
develop (development)
  ↓
feature/* (feature branches)
```

---

**Last Updated:** January 2025
**Maintainer:** Casa Milan Development Team
**Support:** support@casamilan.com
